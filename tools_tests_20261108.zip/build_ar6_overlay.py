"""AR6 淹水／坡地「危害度」疊圖產生器（2026-11-08）。

來源：NCDR「AR6 不同氣候變遷情境（GWLs）災害風險圖」縣市版 JPG（只有圖檔，沒有數值）。
  淹水：網格 40m 危害度；坡地：最小統計區危害度（坡地沒有 40m 版）。
  情境：≈1°C（現況基期，h0_lv）、1.5°C、2°C、4°C（未來推估，H）。

作法（全部自動、可重跑）：
  1. 定位：把我們的縣市界（town_polys.json 合併）投影到 TWD97 TM2，
     與圖上的陸地遮罩比對，搜尋「比例尺＋平移」使兩者重疊（IoU）最大。
     IoU 低於門檻的縣市不輸出（寧可缺，不可疊錯位置）。
  2. 判讀：每張圖從自己的圖例讀出五級色，像素取最接近的級（距離過大＝不是色塊：
     文字、界線、背景），再以 3×3 眾數濾掉 40m 網格疊印的條紋。
  3. 重投影：逐縣市寫進同一張 Web Mercator 拼接圖（Leaflet imageOverlay 用），
     調色盤 PNG、無資料透明。本島＋澎湖一張，金門、連江各一張。
輸出：ar6/<hazard>_<scenario>_<region>.png ＋ ar6/index.json（邊界、IoU、來源檔）。
用法：python3 build_ar6_overlay.py <縣市 JPG 目錄> <輸出目錄>
"""
import os, sys, json, glob, math
import numpy as np
from PIL import Image, ImageDraw
from pyproj import Transformer
from shapely.geometry import Polygon, MultiPolygon
from shapely.ops import unary_union

SRC = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/ar6c'
OUT = sys.argv[2] if len(sys.argv) > 2 else '/home/claude/ar6out'
HERE = os.path.dirname(os.path.abspath(__file__))
os.makedirs(OUT, exist_ok=True)

polys = json.load(open(os.path.join(HERE, 'town_polys.json'), encoding='utf-8'))
COUNTIES = sorted({k[:3] for k in polys})
GROUP = {'新竹縣市': ['新竹縣', '新竹市'], '嘉義縣市': ['嘉義縣', '嘉義市']}

def county_geom(name):
    parts = []
    for c in GROUP.get(name, [name]):
        for k, g in polys.items():
            if k.startswith(c):
                for ring in g[4]:
                    if len(ring) >= 3:
                        p = Polygon(ring)
                        if not p.is_valid: p = p.buffer(0)
                        parts.append(p)
    return unary_union(parts)

TO_TM = {epsg: Transformer.from_crs(4326, epsg, always_xy=True) for epsg in (3826, 3825)}
TO_LL = {epsg: Transformer.from_crs(epsg, 4326, always_xy=True) for epsg in (3826, 3825)}

def geom_rings(geom):
    """經緯度環（圖檔實測為等經緯度投影：寬高比與 lon/lat 等距投影一致，IoU 0.966）。"""
    out = []
    gs = geom.geoms if isinstance(geom, MultiPolygon) else [geom]
    for g in gs:
        lo, la = g.exterior.coords.xy
        out.append((np.c_[np.asarray(lo), np.asarray(la)], 1))
        for h in g.interiors:          # 內洞（新北市中間的臺北市）
            lo, la = h.coords.xy
            out.append((np.c_[np.asarray(lo), np.asarray(la)], 0))
    return out

def raster(rings, sx, sy, E0, N0, cx, cy, size):
    im = Image.new('L', (size, size), 0); d = ImageDraw.Draw(im)
    for r, v in sorted(rings, key=lambda x: -x[1]):   # 先外框後內洞
        d.polygon([((E - E0) * sx + cx, -(N - N0) * sy + cy) for E, N in r], fill=v)
    return np.asarray(im, dtype=bool)

def land_mask(arr):
    m = arr.min(axis=2) < 250
    h, w = m.shape
    m[int(h * .83):, int(w * .78):] = False          # 圖例＋NCDR 標誌
    return m

def fit(img, geom, ds=4):
    """仿射（x、y 各自比例＋平移）：px = sx·(lon−lon0)+cx，py = −sy·(lat−lat0)+cy。"""
    from scipy import ndimage
    arr = np.asarray(img.convert('RGB'))
    size = arr.shape[0] // ds
    lm = land_mask(arr)[::ds, ::ds][:size, :size]
    rings = geom_rings(geom)
    allp = np.vstack([r for r, v in rings if v]); E0, N0 = allp.mean(axis=0)
    def iou(sx, sy, cx, cy):
        r = raster(rings, sx, sy, E0, N0, cx, cy, size)
        u = (r | lm).sum()
        return (r & lm).sum() / u if u else 0
    def init(xs, ys, pts):
        sx = np.ptp(xs) / (np.ptp(pts[:, 0]) or 1); sy = np.ptp(ys) / (np.ptp(pts[:, 1]) or 1)
        cx = (xs.max() + xs.min()) / 2 - ((pts[:, 0].max() + pts[:, 0].min()) / 2 - E0) * sx
        cy = (ys.max() + ys.min()) / 2 + ((pts[:, 1].max() + pts[:, 1].min()) / 2 - N0) * sy
        return [iou(sx, sy, cx, cy), sx, sy, cx, cy]
    # 兩種初值取較好者：主島 vs 最大連通塊；全部 vs 全部（離島縣市）
    lab, n = ndimage.label(lm)
    ys, xs = np.nonzero(lm)
    cands = [init(xs, ys, allp)]
    if n:
        bl = np.bincount(lab.ravel())[1:].argmax() + 1
        y2, x2 = np.nonzero(lab == bl)
        cands.append(init(x2, y2, max([r for r, v in rings if v], key=lambda r: Polygon(r).area)))
    best = max(cands, key=lambda c: c[0])
    for st, sh in ((0.04, 12), (0.01, 4), (0.003, 1), (0.001, 0.5)):
        for _ in range(2):
            b = best[:]
            for d1 in np.arange(-2, 3) * st:
                for d2 in np.arange(-2, 3) * st:
                    for dx in np.arange(-2, 3) * sh:
                        for dy in np.arange(-2, 3) * sh:
                            p = (b[1] * (1 + d1), b[2] * (1 + d2), b[3] + dx, b[4] + dy)
                            v = iou(*p)
                            if v > best[0]: best = [v, *p]
    v, sx, sy, cx, cy = best
    return {'iou': round(float(v), 4), 'sx': sx * ds, 'sy': sy * ds, 'E0': float(E0), 'N0': float(N0),
            'cx': cx * ds, 'cy': cy * ds}

def legend(arr):
    h, w = arr.shape[:2]
    # 圖例五個色框：x≈0.81W，y 從 0.872H 起每 0.018H 一格（所有縣市版版型相同）
    cols = []
    for k in range(5):
        y = int((0.8725 + 0.018 * k) * h); x = int(0.81 * w)
        patch = arr[y - 4:y + 5, x - 6:x + 7].reshape(-1, 3)
        cols.append(np.median(patch, axis=0))
    return np.array(cols)

def classify(arr, leg):
    """像素 → 危害度等級（0＝非色塊）。

    ★ 色彩模型（實測）：坡地圖的色塊是不透明的圖例色；淹水 40m 網格圖則以約 75%
      不透明度疊在灰底（240）上 —— 例如第五級 (0,77,169) 在圖上是 (60,117,186)。
      只比對不透明圖例色時，淹水最高級幾乎全部被當成「非色塊」丟掉。
      故候選色＝圖例原色 ＋ 75% 混灰後的顏色，各自對應同一級。
    ★ 圖上的白底文字框、黑色行政界線、白色河道會在色塊中挖洞：
      白色框（不連到圖外背景）與深色線條，以最近的已判讀像素補齊（限 15 像素內），
      灰色「無納入統計」的陸地維持 0 —— 不把沒有潛勢的地方補成有。
    """
    from scipy import ndimage
    a = arr.astype(float)
    blend = leg * 0.75 + 240 * 0.25
    cands = np.vstack([leg, blend]); lvls = np.r_[np.arange(1, 6), np.arange(1, 6)]
    d = np.stack([np.sqrt(((a - c) ** 2).sum(axis=2)) for c in cands])
    k = d.argmin(axis=0)
    sat = arr.max(axis=2).astype(int) - arr.min(axis=2)
    lv = np.where((d.min(axis=0) < 45) & (sat > 15), lvls[k], 0).astype(np.uint8)
    h, w = lv.shape
    lv[int(h * .83):, int(w * .78):] = 0
    # 洞：①深色線條 ②不連到圖外的白色區塊（文字框、河道）
    dark = arr.max(axis=2) < 110
    white = arr.min(axis=2) >= 248
    lab, n = ndimage.label(white)
    border = set(np.unique(np.r_[lab[0], lab[-1], lab[:, 0], lab[:, -1]]))
    enclosed = white & ~np.isin(lab, list(border))
    fillable = (dark | enclosed) & (lv == 0)
    dist, (iy, ix) = ndimage.distance_transform_edt(lv == 0, return_indices=True)
    fill = fillable & (dist <= 15)
    lv[fill] = lv[iy[fill], ix[fill]]
    # 文字框的白色半透明底疊在深色色塊上，會被讀成第一、二級（圖上看得到一塊塊淺色框）。
    #   只處理「面積小、整圈被同一個 ≥3 級包住」的淺色塊：那是標籤，不是潛勢分布。
    lab2, n2 = ndimage.label((lv == 1) | (lv == 2))
    if n2:
        sizes = ndimage.sum(np.ones_like(lv), lab2, index=np.arange(1, n2 + 1))
        objs = ndimage.find_objects(lab2)
        for idx_, (sl, sz) in enumerate(zip(objs, sizes), start=1):
            if sz > 3000 or sl is None: continue
            y0, y1 = max(0, sl[0].start - 2), min(h, sl[0].stop + 2)
            x0, x1 = max(0, sl[1].start - 2), min(w, sl[1].stop + 2)
            comp = lab2[y0:y1, x0:x1] == idx_
            ring = ndimage.binary_dilation(comp, iterations=2) & ~comp
            rv = lv[y0:y1, x0:x1][ring]
            if rv.size == 0: continue
            vals, cnts = np.unique(rv, return_counts=True)
            top = vals[cnts.argmax()]
            if top >= 3 and cnts.max() / rv.size >= 0.85:
                sub = lv[y0:y1, x0:x1]; sub[comp] = top
    # 3×3 眾數，消掉網格疊印的條紋
    pad = np.pad(lv, 1)
    stack = np.stack([pad[i:i + h, j:j + w] for i in range(3) for j in range(3)])
    cnt = np.stack([(stack == k_).sum(axis=0) for k_ in range(6)])
    mode = cnt[1:].argmax(axis=0) + 1
    has = cnt[1:].max(axis=0) >= 3
    return np.where((lv > 0) & has, mode, lv).astype(np.uint8)

# Web Mercator 拼接範圍
REGIONS = {
    'main':   (119.30, 21.85, 122.10, 25.35, 3600),
    'kinmen': (118.13, 24.36, 118.52, 24.54, 900),
    'matsu':  (119.88, 25.92, 120.53, 26.40, 900),
}
def merc(lon, lat):
    return lon * 20037508.34 / 180, math.log(math.tan(math.pi / 4 + math.radians(lat) / 2)) * 6378137

def region_grid(reg):
    lo0, la0, lo1, la1, W = REGIONS[reg]
    x0, y0 = merc(lo0, la0); x1, y1 = merc(lo1, la1)
    H = int(round(W * (y1 - y0) / (x1 - x0)))
    xs = x0 + (np.arange(W) + .5) * (x1 - x0) / W
    ys = y1 - (np.arange(H) + .5) * (y1 - y0) / H
    lon = xs * 180 / 20037508.34
    lat = np.degrees(2 * np.arctan(np.exp(ys / 6378137)) - math.pi / 2)
    return W, H, lon, lat

REG_OF = {'金門縣': 'kinmen', '連江縣': 'matsu'}
PAL = {  # 疊圖用色（半透明由前端控制）：淹水藍、坡地棕，五級由淺到深
    'flood': [(198, 226, 255), (140, 196, 245), (74, 150, 222), (24, 98, 190), (8, 48, 130)],
    'slope': [(255, 230, 190), (250, 196, 128), (232, 146, 62), (196, 92, 24), (130, 48, 8)],
}
MIN_IOU = 0.90
#  離島群島縣：陸地細碎、我們的鄉鎮界又經過簡化，IoU 天生偏低（澎湖 0.67、金門 0.89），
#  但把縣界疊回原圖目視檢查，輪廓逐島吻合（2026-11-08 檢查，圖存 ar6/verify_*.jpg）。
#  連江縣定位失敗（IoU 0.12，輪廓落在圖外），不輸出。
MANUAL_OK = {'澎湖縣', '金門縣'}

def main():
    files = sorted(glob.glob(os.path.join(SRC, '*.jpg')))
    index = {'regions': {}, 'layers': {}, 'counties': {}}
    fcache = os.path.join(OUT, 'fits.json')
    fits = {}
    if os.path.exists(fcache):
        fits = {tuple(k.split('/')): v for k, v in json.load(open(fcache, encoding='utf-8')).items()}
    grids = {r: region_grid(r) for r in REGIONS}
    canv = {}
    for f in files:
        hz, cty, sc = os.path.basename(f)[:-4].split('_')
        key = (hz, cty)
        img = Image.open(f).convert('RGB')
        if key not in fits:
            geom = county_geom(cty)
            fits[key] = fit(img, geom)
            json.dump({'/'.join(k): v for k, v in fits.items()}, open(fcache, 'w', encoding='utf-8'),
                      ensure_ascii=False)
            print(f'{hz} {cty}: IoU {fits[key]["iou"]:.3f}')
        index['counties'][f'{hz}/{cty}'] = {'iou': fits[key]['iou']}
        F = fits[key]
        if F['iou'] < MIN_IOU and cty not in MANUAL_OK:
            print(f'  ✗ {cty} 定位重疊度不足，不輸出'); continue
        arr = np.asarray(img)
        lv = classify(arr, legend(arr))
        reg = REG_OF.get(cty, 'main')
        W, H, lon, lat = grids[reg]
        ck = (hz, sc, reg)
        if ck not in canv: canv[ck] = np.zeros((H, W), np.uint8)
        LON, LAT = np.meshgrid(lon, lat)
        g = county_geom(cty); b = g.bounds
        sel = (LON >= b[0]) & (LON <= b[2]) & (LAT >= b[1]) & (LAT <= b[3])
        E, N = LON[sel], LAT[sel]
        px = ((E - F['E0']) * F['sx'] + F['cx']).astype(int)
        py = (-(N - F['N0']) * F['sy'] + F['cy']).astype(int)
        ok = (px >= 0) & (px < arr.shape[1]) & (py >= 0) & (py < arr.shape[0])
        vals = np.zeros(px.shape, np.uint8); vals[ok] = lv[py[ok], px[ok]]
        sub = canv[ck][sel]; sub = np.maximum(sub, vals); canv[ck][sel] = sub
    for (hz, sc, reg), a in canv.items():
        im = Image.fromarray(a, 'P')
        pal = [0, 0, 0] + [c for rgb in PAL[hz] for c in rgb]
        im.putpalette(pal + [0] * (768 - len(pal)))
        fn = f'{hz}_{sc}_{reg}.png'
        im.save(os.path.join(OUT, fn), transparency=0, optimize=True)
        lo0, la0, lo1, la1, _ = REGIONS[reg]
        index['regions'][reg] = [[la0, lo0], [la1, lo1]]
        index['layers'].setdefault(hz, {}).setdefault(sc, []).append({'region': reg, 'file': fn,
            'cells': int((a > 0).sum())})
        print(f'  → {fn} {os.path.getsize(os.path.join(OUT, fn)) // 1024} KB，色塊像素 {(a > 0).sum()}')
    index['source'] = 'NCDR AR6 GWLs 災害風險圖（縣市版 JPG）危害度：淹水網格40m、坡地最小統計區'
    index['note'] = '僅供氣候變遷調適之相對風險辨識（NCDR 使用限制），不代表即時災害預測'
    json.dump(index, open(os.path.join(OUT, 'index.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

if __name__ == '__main__':
    main()
