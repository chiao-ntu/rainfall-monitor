// 2026-11-08 新增圖層守門：AR6 危害度、村里界、交通下拉、重要公共設施、各國颱風路徑。
//   ‧ 未開啟前不下載（首頁不被拖慢）
//   ‧ 開得起來、畫得出東西、tooltip 有內容、關得乾淨
//   ‧ 線／面 pane 一律不攔截指標事件（否則鄉鎮點不到）
//   ‧ 不拖慢鄉鎮著色
const puppeteer=require('puppeteer');
(async()=>{
 const b=await puppeteer.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
   args:['--no-sandbox','--disable-dev-shm-usage'],defaultViewport:{width:1400,height:900}});
 const pg=await b.newPage(); const errs=[], req=[];
 pg.on('pageerror',e=>errs.push(String(e).slice(0,200)));
 pg.on('request',r=>req.push(r.url()));
 await pg.goto('http://127.0.0.1:8899/_local.html',{waitUntil:'networkidle2',timeout:120000});
 await new Promise(r=>setTimeout(r,6000));
 const early=req.filter(u=>/ar6\/|villages\/|transport\.json|schools\.json|multity\.json/.test(u));
 const R=await pg.evaluate(async(early)=>{
  const fails=[], log=[];
  const ok=(c,m)=>{ if(!c) fails.push(m); log.push((c?'OK  ':'!!  ')+m); };
  const wait=ms=>new Promise(r=>setTimeout(r,ms));
  ok(early.length===0, `①未開啟前不下載新圖資（實得 ${early.length} 筆）`);
  ['bAr6','bTrans','bFac','bMty'].forEach(id=>ok(!!document.getElementById(id), `①按鈕 ${id} 存在`));
  ok(!document.querySelector('#layer-row2 button#bRoads'), '①原「道路」按鈕已併入「交通」下拉');
  const bench=()=>{ const t=performance.now(); try{ renderLayer(); }catch(e){} return performance.now()-t; };
  bench(); const base=Math.min(bench(),bench(),bench());

  // ── AR6 ──
  openAr6Menu(document.getElementById('bAr6'));
  const m=document.getElementById('ddAr6');
  ok(m && m.style.display==='block' && m.querySelectorAll('input[type=radio]').length===4,
     '②AR6 下拉：四種情境可選');
  await _ar6Set('flood', true); await wait(1500);
  ok(_ar6.layers.length>=1, `②淹水危害度疊圖 ${_ar6.layers.length} 張`);
  ok(map.getPane('ar6Pane').style.pointerEvents==='none', '②ar6Pane 不攔截點擊');
  // 宜蘭五結（淹水高潛勢）取得等級
  const lv=_ar6LevelAt('flood', L.latLng(24.69, 121.79));
  ok(lv>=3, `②宜蘭五結淹水危害度可讀出（第 ${lv} 級）`);
  const lvMt=_ar6LevelAt('flood', L.latLng(24.45, 121.35));
  ok(lvMt===0, `②中央山脈無淹水危害（實得 ${lvMt}）`);
  for(const [k] of AR6_SC){ await _ar6Scen(k); ok(_ar6.layers.length>=1, `②情境 ${k} 有疊圖`); }
  await _ar6Set('slope', true); await wait(800);
  ok(/坡地危害度/.test(document.getElementById('overlay-legend').innerHTML), '②圖例列出坡地危害度');
  await _ar6Set('flood', false); await _ar6Set('slope', false);
  ok(_ar6.layers.length===0, '②關閉後疊圖移除');

  // ── 交通 ──
  await _trSet('rail', true); await _trSet('hsr', true); await _trSet('st_hsr', true);
  await _trSet('airport', true); await wait(500);
  ok(_tr.data && _tr.data.rail.length>10, `③交通圖資載入（臺鐵 ${_tr.data && _tr.data.rail.length} 條）`);
  ok(map.getPane('railPane').style.pointerEvents==='none', '③railPane 不攔截點擊');
  ok(_tr.pt && _tr.pt.getLayers().length>0, `③車站／機場點 ${_tr.pt && _tr.pt.getLayers().length} 個`);
  ok(/交通/.test(document.getElementById('overlay-legend').innerHTML), '③圖例列出交通');
  const withL=Math.min(bench(),bench(),bench());
  ok(withL < base*2+25, `③不拖慢鄉鎮著色（${base.toFixed(0)}→${withL.toFixed(0)}ms）`);
  await _trSet('road', true); await wait(2000);
  ok(_roadOn, '③下拉「道路」開啟既有道路圖層');
  await _trSet('road', false);
  ['rail','hsr','st_hsr','airport'].forEach(k=>_tr.on[k]=false); renderTransLayer();
  ok(!_tr.pt || _tr.pt.getLayers().length===0, '③交通關閉後清空');

  // ── 學校 ──
  map.setView([25.03, 121.52], 14, {animate:false}); await wait(400);
  await _facSet('school', true); await wait(600);
  ok(_fac.pt && _fac.pt.getLayers().length>5, `④學校點（臺北市中心 ${_fac.pt && _fac.pt.getLayers().length} 處）`);
  ok(!!_fac.poly, '④放大 14 級顯示校地範圍');
  await _facSet('school', false);

  // ── 村里界（跟行政區名綁定）──
  if(!showTownName) toggleTownNameLayer();
  await wait(2500);
  ok(!!_vill.layer, '⑤行政區名開啟且放大 ≥12 → 村里界');
  ok(_vill.lbl && _vill.lbl.getLayers().length>5, `⑤村里名稱 ${_vill.lbl && _vill.lbl.getLayers().length} 個`);
  ok(map.getPane('villPane').style.pointerEvents==='none', '⑤villPane 不攔截點擊');
  map.setZoom(10, {animate:false}); await wait(800);
  ok(!_vill.layer, '⑤縮小到 12 級以下不畫村里');
  toggleTownNameLayer(); await wait(300);

  // ── 各國颱風路徑 ──
  await _mtyLoad();
  ok(_mtyGroups().size>=2, `⑥各國路徑分組 ${_mtyGroups().size} 組`);
  if(!showTyphoon) toggleTyphoonLayer(); await wait(500);
  ok(_mty.layer && _mty.layer.getLayers().length>0, '⑥颱風圖層開啟時畫出各國路徑');
  const k0=[..._mtyGroups().keys()][0];
  const n0=_mty.layer.getLayers().length;
  _mtySet(k0, false); await wait(300);
  ok(_mty.layer.getLayers().length < n0, `⑥取消勾選「${k0}」後該組不畫（${n0}→${_mty.layer.getLayers().length}）`);
  ok(JSON.parse(localStorage.getItem(MTY_LS)||'[]').indexOf(k0)<0, '⑥勾選記住（localStorage）');
  _mtyAll(true); toggleTyphoonLayer(); await wait(200);
  ok(!_mty.layer, '⑥颱風圖層關閉時各國路徑一起移除');
  return {fails, log};
 }, early);
 console.log(R.log.join('\n'));
 if(errs.length) console.log('\n*** pageerror ***\n'+errs.join('\n'));
 console.log(`\n${R.fails.length?'FAIL '+R.fails.length:'ALL PASS'} / ${R.log.length} 項`);
 await b.close();
 process.exit(R.fails.length||errs.length?1:0);
})();
