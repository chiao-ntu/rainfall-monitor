"""收容所／救濟站：新舊比對（ODS 2026-11-08 匯出 vs 現行 shelters.geojson）。"""
import sys, json, re, collections
sys.path.insert(0, '/tmp'); from readods import read_ods
def n(s): return re.sub(r'[\s　()（）・．\.、,，\-－]', '', (s or '').replace('台', '臺'))
def num(s):  # 地址 → 去縣市/區/村里/鄰後的「路街巷弄號」
    s = n(s)
    s = re.sub(r'^.*?[縣市](?=.{2,}[區鄉鎮市])', '', s, count=1)
    s = re.sub(r'^.{1,4}?[區鄉鎮市]', '', s, count=1)
    s = re.sub(r'^.{1,5}?[里村](?=.)', '', s, count=1)
    s = re.sub(r'\d+鄰', '', s)
    s = re.sub(r'(\d+)之(\d+)', r'\1-\2', s).replace('號', '')
    s = re.sub(r'[一二三四五六七八九十]樓|\d+樓|\d+F', '', s)
    return s
def dist(addr):
    m = re.search(r'(?:[縣市])([^縣市]{1,4}?[區鄉鎮市])', n(addr)); return m.group(1) if m else ''
G = json.load(open(sys.argv[1], encoding='utf-8'))['features']
def load(f): return [r for r in read_ods(f)[1:] if len(r) >= 4]
S = load(sys.argv[2]); RS = load(sys.argv[3])
by_name = collections.defaultdict(list); by_addr = collections.defaultdict(list)
for f in G:
    p = f['properties']; c = n(p['cty'])
    by_name[(c, n(p['name']))].append(f)
    a = num(p.get('addr'))
    if a: by_addr[(c, a)].append(f)
def match(r):
    c = n(r[0])
    if (c, n(r[1])) in by_name: return 'name', by_name[(c, n(r[1]))][0]
    a = num(r[3])
    if a and (c, a) in by_addr:
        return 'addr', by_addr[(c, a)][0]
    return None, None
out = {'shelter': [], 'relief': []}
st = collections.Counter()
used = set()
for kind, rows in (('shelter', S), ('relief', RS)):
    for r in rows:
        how, f = match(r)
        st[(kind, how or 'none')] += 1
        if f is not None and kind == 'shelter': used.add(id(f))
        out[kind].append({'cty': r[0], 'name': r[1], 'tel': r[2], 'addr': r[3], 'how': how,
                          'xy': f['geometry']['coordinates'] if f else None,
                          'old': {k: f['properties'].get(k) for k in ('cap', 'haz', 'cvil', 'weak', 'ind', 'out')} if f else None})
gone = [f['properties'] for f in G if id(f) not in used]
print(dict(st)); print('舊檔有、新檔沒有', len(gone))
json.dump({'out': out, 'gone': [{'cty': p['cty'], 'name': p['name'], 'addr': p.get('addr')} for p in gone]},
          open(sys.argv[4], 'w', encoding='utf-8'), ensure_ascii=False)
