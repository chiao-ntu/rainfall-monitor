"""國土測繪中心（NLSC）圖資 → 前端靜態圖層（2026-11-08）。

輸入：NLSC shapefile 目錄（村里界、鐵路、高鐵、捷運、輕軌、臺鐵／捷運／高鐵車站、機場、碼頭、各級學校範圍圖）
輸出（OUT 目錄）：
  villages/<縣市>.json  村里界（依縣市分檔，前端放大且縣市在畫面內才載入），名稱綁「縣市＋鄉鎮＋村里」
  villages/index.json  各縣市外框與檔名
  transport.json       鐵路／高鐵／捷運／輕軌（線）＋臺鐵／高鐵／捷運車站、機場、碼頭（點）
  schools.json         各級學校（範圍多邊形＋代表點）
座標：一律轉 WGS84（TWD97 與 WGS84 差異 < 1m），小數 5 位（約 1m）。
簡化：村里 12m、學校 5m、路線 20m（Douglas-Peucker，保拓撲）。
用法：python3 build_static_layers.py <NLSC 目錄> <輸出目錄>
"""
import os, sys, json, re, collections
import shapefile
from pyproj import Transformer, CRS
from shapely.geometry import shape, mapping, Polygon, MultiPolygon, LineString, MultiLineString
from shapely.ops import unary_union

SRC = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/nlsc'
OUT = sys.argv[2] if len(sys.argv) > 2 else '/home/claude/layers'
os.makedirs(os.path.join(OUT, 'villages'), exist_ok=True)

def reader(name):
    p = os.path.join(SRC, name)
    for enc in ('utf-8', 'cp950'):
        try:
            r = shapefile.Reader(p, encoding=enc); r.record(0); return r
        except Exception:
            pass
    raise RuntimeError(name)

def to_wgs(name):
    prj = open(os.path.join(SRC, name[:-4] + '.prj'), encoding='utf-8', errors='ignore').read()
    if prj.startswith('GEOGCS'):
        return None
    if 'Penghu' in prj or 'zone_119' in prj or '119' in prj.split('PROJECTION')[0]:
        return Transformer.from_crs(3825, 4326, always_xy=True)
    return Transformer.from_crs(3826, 4326, always_xy=True)

def geom_of(sr, tf):
    g = shape(sr.shape.__geo_interface__)
    if tf is None:
        return g
    from shapely.ops import transform
    return transform(lambda x, y, z=None: tf.transform(x, y), g)

R5 = lambda v: round(v, 5)
def ring_out(r):
    return [[R5(x), R5(y)] for x, y in r.coords]
def poly_out(g):
    gs = g.geoms if isinstance(g, MultiPolygon) else [g]
    return [[ring_out(p.exterior)] + [ring_out(i) for i in p.interiors] for p in gs if not p.is_empty]
def line_out(g):
    gs = g.geoms if isinstance(g, MultiLineString) else [g]
    return [ring_out(l) for l in gs if not l.is_empty]

def norm_tai(s):
    return (s or '').replace('台', '臺').strip()

# ── 村里 ──
vr = reader('VILLAGE_NLSC_1150817.shp'); tf = to_wgs('VILLAGE_NLSC_1150817.shp')
by_cty = collections.defaultdict(list)
def add_village(rec, g):
    g = g.buffer(0) if not g.is_valid else g
    gs = g.simplify(0.00012, preserve_topology=True)
    by_cty[norm_tai(rec['COUNTYNAME'])].append({
        't': norm_tai(rec['TOWNNAME']), 'v': norm_tai(rec['VILLNAME']) or '（未編定村里）',
        'id': rec['VILLCODE'], 'p': poly_out(gs),
        'c': [R5(gs.representative_point().x), R5(gs.representative_point().y)]})
for sr in vr.iterShapeRecords():
    add_village(sr.record, geom_of(sr, tf))
# 三和村（瑪家鄉）補充檔：主檔無此村
sh = reader('Village_Sanhe.shp')
for sr in sh.iterShapeRecords():
    if not any(f['id'] == sr.record['VILLCODE'] for f in by_cty[norm_tai(sr.record['COUNTYNAME'])]):
        add_village(sr.record, geom_of(sr, to_wgs('Village_Sanhe.shp')))
idx = {}
for i, (cty, feats) in enumerate(sorted(by_cty.items())):
    fn = f'v{i:02d}.json'
    xs = [pt[0] for f in feats for poly in f['p'] for pt in poly[0]]
    ys = [pt[1] for f in feats for poly in f['p'] for pt in poly[0]]
    idx[cty] = {'file': fn, 'n': len(feats), 'bbox': [min(xs), min(ys), max(xs), max(ys)],
                'towns': sorted({f['t'] for f in feats})}
    json.dump({'county': cty, 'feats': feats}, open(os.path.join(OUT, 'villages', fn), 'w', encoding='utf-8'),
              ensure_ascii=False, separators=(',', ':'))
json.dump({'source': 'NLSC 村里界 1150817（含瑪家鄉三和村補充檔）', 'counties': idx},
          open(os.path.join(OUT, 'villages', 'index.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
print('村里', sum(v['n'] for v in idx.values()), '縣市', len(idx))

# ── 交通 ──
T = {'source': 'NLSC 交通圖資（鐵路/捷運/輕軌/碼頭/車站 1150409；高鐵/機場 1101208；臺鐵車站 1140206）'}
def lines(name, namef, extra=None, keep=lambda r: True):
    r = reader(name); tf = to_wgs(name); out = []; skipped = collections.Counter()
    for sr in r.iterShapeRecords():
        rec = sr.record
        if not keep(rec):
            skipped[(rec[namef] if namef else '') or '（無名）'] += 1; continue
        g = geom_of(sr, tf).simplify(0.0002, preserve_topology=True)
        f = {'n': norm_tai(rec[namef]) if namef else '', 'l': line_out(g)}
        if extra: f.update({k: norm_tai(str(rec[v])) for k, v in extra.items()})
        out.append(f)
    # 同名合併（減少物件數）
    m = collections.OrderedDict()
    for f in out:
        k = (f['n'], f.get('s', ''))
        m.setdefault(k, dict(f, l=[])); m[k]['l'] += f['l']
    return list(m.values()), skipped
status0 = lambda r: int(r['STATUS'] or 0) == 0
T['rail'], sk_rail = lines('RAIL_1150409.shp', 'RAILNAME', keep=status0)
T['hsr'], _ = lines('HSRAIL_1101208.shp', 'HSNAME')
T['mrt'], sk_mrt = lines('MRT_1150409.shp', 'MRTCODE', {'s': 'MRTSYS'}, keep=status0)
T['lrt'], sk_lrt = lines('LRT_1150409.shp', 'LRTCODE', {'s': 'LRTSYS'}, keep=status0)
T['not_shown_status'] = {'rail': dict(sk_rail), 'mrt': dict(sk_mrt), 'lrt': dict(sk_lrt)}

def points(name, namef='MARKNAME1', addr=True):
    r = reader(name); tf = to_wgs(name); out = []
    for sr in r.iterShapeRecords():
        x, y = sr.shape.points[0]
        if tf: x, y = tf.transform(x, y)
        rec = sr.record
        f = {'n': norm_tai(rec[namef]), 'c': [R5(x), R5(y)]}
        if addr and 'ADDRESS' in rec.as_dict() and rec['ADDRESS']: f['a'] = norm_tai(rec['ADDRESS'])
        if 'TEL' in rec.as_dict() and rec['TEL']: f['tel'] = rec['TEL']
        out.append(f)
    return out
T['st_tra'] = points('MARK_臺鐵車站_1140206.shp')
T['st_hsr'] = points('MARK_高鐵車站_1101208.shp')
# 捷運：圖資是「出入口」層級 → 依站名合併成一站（座標取出入口平均）
mrt_raw = points('MARK_捷運車站_1150409.shp')
grp = collections.OrderedDict()
for f in mrt_raw:
    st = re.sub(r'[-_](出入口\s*\d*|[A-Z]{0,2}\d+[A-Z]?)$', '', f['n'])
    grp.setdefault(st, []).append(f)
T['st_mrt'] = [{'n': k, 'c': [R5(sum(p['c'][0] for p in v) / len(v)), R5(sum(p['c'][1] for p in v) / len(v))],
                'exits': len(v)} for k, v in grp.items()]
def dedupe(fs):
    # 本島檔與離島檔有重疊（馬祖機場兩檔都有）：同名且相距 < 300m 視為同一筆
    out = []
    for f in fs:
        if any(o['n'] == f['n'] and abs(o['c'][0] - f['c'][0]) < .003 and abs(o['c'][1] - f['c'][1]) < .003 for o in out):
            continue
        out.append(f)
    return out
T['airport'] = dedupe(points('MARK_機場_121_1101208.shp') + points('MARK_機場_119_1101208.shp'))
T['port'] = dedupe(points('MARK_碼頭_121_1150409.shp') + points('MARK_碼頭_119_1120412.shp'))
json.dump(T, open(os.path.join(OUT, 'transport.json'), 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
print('交通', {k: len(v) for k, v in T.items() if isinstance(v, list)}, '未顯示（STATUS≠0）', T['not_shown_status'])

# ── 學校 ──
sr_ = reader('各級學校範圍圖_121_1150409.shp'); tf = to_wgs('各級學校範圍圖_121_1150409.shp')
S = []
for sr in sr_.iterShapeRecords():
    g = geom_of(sr, tf); g = g.buffer(0) if not g.is_valid else g
    gs = g.simplify(0.00005, preserve_topology=True)
    pt = gs.representative_point()
    S.append({'n': norm_tai(sr.record['BLOCKNAME']), 'c': [R5(pt.x), R5(pt.y)], 'p': poly_out(gs)})
json.dump({'source': 'NLSC 各級學校範圍圖 1150409', 'feats': S},
          open(os.path.join(OUT, 'schools.json'), 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
print('學校', len(S))
for root, _, fs in os.walk(OUT):
    for f in fs:
        p = os.path.join(root, f)
print('總大小 KB', sum(os.path.getsize(os.path.join(r, f)) for r, _, fs in os.walk(OUT) for f in fs) // 1024)
