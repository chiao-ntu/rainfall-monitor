"""前端會讀的檔案，必須都在 publish_to_public.yml 的發布清單裡（2026-11-08）。

事故：roads_detail.geojson 前端會讀，卻不在發布清單 —— 公開版的次要／集散道路
永遠載入失敗。這次新增的 transport.json、schools.json、villages/、ar6/、multity.json
同樣要發布，靠人記不住，改成機器比對。
"""
import re, sys, os
H = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(H, 'index.html'), encoding='utf-8').read()
wf = open(os.path.join(H, sys.argv[1] if len(sys.argv) > 1 else 'publish_to_public.yml'), encoding='utf-8').read()
used = set(re.findall(r"_loadJsonOnce\(\s*'([^'$`]+?)'", src))
used |= set(re.findall(r"fetch\(\s*'([\w./-]+\.(?:json|geojson|png))", src))
used |= set(re.findall(r"L\.imageOverlay\(\s*'([\w./-]+)/'", src))   # 資料夾
dirs = set(re.findall(r'for d in ([\w ]+); do', wf))
dirs = {x for g in dirs for x in g.split()}
files = set(re.findall(r'([\w.-]+\.(?:json|geojson|png|txt))', wf))
miss = []
for u in sorted(used):
    top = u.split('/')[0]
    if '/' in u and top in dirs: continue
    if u in files or u.rstrip('/') in dirs: continue
    miss.append(u)
print('前端讀取：', sorted(used))
for m in miss: print('FAIL 未發布：', m)
print('PASS' if not miss else f'FAIL ×{len(miss)}')
sys.exit(1 if miss else 0)
