"""防止「72hr 與 Weekday 互相覆蓋」再發生（2026-11-08 平均風／陣風偏低事故）。

以官方 F-D0047-093 打包檔實檔驗證：
  1. 合併後的風力／氣溫序列在 72hr 涵蓋範圍內必須是逐 3 小時（res==3）。
  2. 解析順序（72hr 先 or Weekday 先）不得影響結果。
  3. 72hr 之後由 Weekday 接續，時間不重疊、不倒退。
  4. 每一個 3 小時值都與官方檔案原值一致（不內插、不推估）。
用法：python3 test_wind_merge.py [F-D0047-093.zip]
"""
import sys, os, re, zipfile, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fetch_rainfall as fr

ZIP = sys.argv[1] if len(sys.argv) > 1 else '/mnt/user-data/uploads/F-D0047-093.zip'
zf = zipfile.ZipFile(ZIP)
files = [n for n in zf.namelist() if n.endswith('_CH.xml') and not n.startswith('TAIWAN')
         and ('_72hr_' in n or '_Weekday_' in n)]
fails = []

def run(order):
    fr.WIND_FCST.clear(); fr.TEMP_FCST.clear()
    for n in order:
        txt = zf.read(n).decode('utf-8', 'replace')
        m = re.search(r'<LocationsName>([^<]+)</LocationsName>', txt)
        county = (m.group(1).strip() if m else '').replace('台', '臺')
        fr._extract_pop_wind(fr._parse_pop_wind_xml(txt, county), county, '_72hr_' in n)
    return copy.deepcopy(fr.WIND_FCST), copy.deepcopy(fr.TEMP_FCST)

fwd = sorted(files)                                   # 檔內原順序：72hr → Weekday
rev = sorted(files, key=lambda n: ('_72hr_' in n, n))  # 反過來：Weekday → 72hr
W1, T1 = run(fwd)
W2, T2 = run(rev)

def strip(d):
    return {c: {t: [(x['start'], x.get('end'), x.get('ws', x.get('t')), x.get('res')) for x in s]
                for t, s in v.items()} for c, v in d.items()}

if strip(W1) != strip(W2): fails.append('風力：解析順序不同結果不同')
if strip(T1) != strip(T2): fails.append('氣溫：解析順序不同結果不同')

# 官方 72hr 原值（獨立解析，不經合併）
import xml.etree.ElementTree as ET
ref = {}
for n in files:
    if '_72hr_' not in n: continue
    txt = re.sub(r'\sxmlns="[^"]+"', '', zf.read(n).decode('utf-8'), count=1)
    r = ET.fromstring(txt)
    county = (r.findtext('.//LocationsName') or '').replace('台', '臺')
    for loc in r.iter('Location'):
        for we in loc.findall('WeatherElement'):
            for t in we.findall('Time'):
                ev = t.find('ElementValue')
                ws = ev.findtext('WindSpeed') if ev is not None else None
                if ws:
                    ref[(county, loc.findtext('LocationName'), t.findtext('DataTime'))] = fr._numstr(ws)

n_town = n3 = 0
for c, towns in W1.items():
    for t, segs in towns.items():
        n_town += 1
        r3 = [x for x in segs if x.get('res') == 3]
        if not r3:
            fails.append(f'{c}{t}：沒有任何逐 3 小時風力'); continue
        n3 += len(r3)
        last = None
        for x in segs:
            st = fr._iso_ms(x['start'])
            if last is not None and st < last:
                fails.append(f'{c}{t}：時間倒退或重疊 {x["start"]}'); break
            last = fr._iso_ms(x.get('end') or x['start'])
        for x in r3:
            k = (c, t, x['start'])
            if k in ref and ref[k] != x.get('ws'):
                fails.append(f'{c}{t} {x["start"]}：{x.get("ws")} ≠ 官方 {ref[k]}')
        # 72hr 範圍內不得出現 12h 值
        end3 = max(fr._iso_ms(x.get('end') or x['start']) for x in r3)
        bad = [x for x in segs if x.get('res') == 12 and fr._iso_ms(x['start']) < end3]
        if bad: fails.append(f'{c}{t}：72hr 範圍內混入逐 12 小時值')

print(f'鄉鎮 {n_town}、逐 3 小時風力 {n3} 筆、官方對照 {len(ref)} 筆')
if n_town < 360: fails.append(f'鄉鎮數 {n_town} < 360')
for f in fails[:20]: print('FAIL', f)
print('PASS' if not fails else f'FAIL ×{len(fails)}')
sys.exit(1 if fails else 0)
