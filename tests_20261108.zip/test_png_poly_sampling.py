"""色塊判讀改為「鄉鎮界內取樣」的守門（2026-11-08，使用者：色塊判讀不準必須克服）。

以合成圖驗證（不需網路）：用與正式判讀相同的單應性，把每個鄉鎮的多邊形塗上
已知色帶、畫黑色界線（模擬官方圖的縣市界），再跑 decode_qpf_png。
  1. 界內取樣：每個鄉鎮讀回的色帶必須等於塗上去的色帶（容許極少數 <2%）。
  2. 對照舊法（質心圓）：準確率必須明顯較低 —— 證明這次改動確實修到問題，
     而不是兩種方法一樣好。
  3. 真實資料的鄉鎮全部都有鄉鎮界可用（不是靠退路撐著）。
"""
import os, sys, json, io
os.environ.setdefault('CWA_API_KEY', 'dummy')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fetch_rainfall as fr
from datetime import datetime
from PIL import Image, ImageDraw

fails = []
def ok(c, m):
    print(('OK  ' if c else '!!  ') + m)
    if not c: fails.append(m)

polys = fr._load_town_polys()
towns = json.load(open('all_townships.json', encoding='utf-8'))
towns = towns.get('townships', towns) if isinstance(towns, dict) else towns
ok(len(polys) >= 368, f'鄉鎮界 {len(polys)} 個')
keys = [f"{t['county']}{t['township']}" for t in towns]
ok(all(k in polys for k in keys), f'{len(keys)} 個鄉鎮全部有鄉鎮界（缺 {[k for k in keys if k not in polys][:5]}）')

H3 = fr._png_solve_homography(fr.CAPES_PX, fr.CAPES_LL)
W, H = fr.QPF_PNG_REF_SIZE
img = Image.new('RGB', (W, H), (255, 255, 255))
dr = ImageDraw.Draw(img)
bands = [b for b in fr.QPF_PNG_BANDS if b[3] >= 1]       # 不用 0.5 灰（與文字灰相近）
truth = {}
for i, k in enumerate(sorted(polys)):
    r, g, b, v = bands[(i * 7) % len(bands)]               # 相鄰鄉鎮盡量不同色
    truth[k] = v
    for ring in polys[k][4]:
        pts = [fr._png_ll2px(H3, lo, la) for lo, la in ring]
        if len(pts) >= 3:
            dr.polygon(pts, fill=(r, g, b))
for k in polys:                                             # 黑色界線（官方圖的行政界）
    for ring in polys[k][4]:
        pts = [fr._png_ll2px(H3, lo, la) for lo, la in ring]
        if len(pts) >= 3:
            dr.line(pts + [pts[0]], fill=(0, 0, 0), width=1)
buf = io.BytesIO(); img.save(buf, 'PNG'); png = buf.getvalue()

now = datetime(2026, 11, 8, 12)
def run():
    segs = fr.decode_qpf_png(png, 'TEST', now, towns, win_seg=0, win_nseg=2)
    return next(iter(segs.values())) if segs else {}

#  官方圖的範圍不含金門、連江（投影在圖外），兩種方法都讀不到，不列入比較
def _inside(k):
    for ring in polys[k][4]:
        pts = [fr._png_ll2px(H3, lo, la) for lo, la in ring]
        if pts and all(0 <= x < W and 0 <= y < H for x, y in pts): return True
    return False
keys = [k for k in keys if _inside(k)]
print(f'    圖面範圍內的鄉鎮 {len(keys)} 個')
got = run()
good = sum(1 for k in keys if got.get(k) == truth.get(k))
acc_poly = good / len(keys)
ok(acc_poly >= 0.98, f'①界內取樣：{good}/{len(keys)} 鄉鎮讀回正確色帶（{acc_poly:.1%}）')
print('    新法讀錯的例子：', [(k, truth[k], got.get(k)) for k in keys if got.get(k) != truth.get(k)][:6])

fr._TOWN_POLYS_CACHE = {}                                   # 關掉鄉鎮界 → 舊法質心圓
got_c = run()
good_c = sum(1 for k in keys if got_c.get(k) == truth.get(k))
acc_c = good_c / len(keys)
ok(acc_c < acc_poly - 0.05, f'②舊法質心圓：{good_c}/{len(keys)}（{acc_c:.1%}）—— 新法明顯較準')
bad_c = [k for k in keys if got_c.get(k) != truth.get(k)][:6]
print('    舊法讀錯的例子：', bad_c)

print('\n全部通過' if not fails else f'\n失敗 {len(fails)} 項：{fails}')
sys.exit(1 if fails else 0)
