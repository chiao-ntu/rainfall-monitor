"""F-C0041（陸上颱風警報期間 QPF 格點）新鮮度守門（2026-11-08）。

F-C0041 只在颱風警報期間更新，警報解除後舊檔仍在（7/12 那一報到 8 月底還抓得到）。
  1. 發布超過 12 小時 → 不採用（回空）。
  2. 發布 12 小時內 → 採用，8 段都在、格點數正確。
  3. cwa_overlay 遇到解析不到時段的颱風段 → 跳過，不得猜成「現在起第 i 段」。
用法：python3 test_typhoon_qpf_fresh.py   （讀 /mnt/user-data/uploads/F-C0041-00N.json）
"""
import os, sys, json, glob
os.environ.setdefault('CWA_API_KEY', 'dummy')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fetch_rainfall as fr
from datetime import datetime

UP = '/mnt/user-data/uploads'
files = {i: (glob.glob(f'{UP}/*F-C0041-00{i}.json') or [None])[0] for i in range(1, 9)}
fails = []
def ok(c, m):
    print(('OK  ' if c else '!!  ') + m)
    if not c: fails.append(m)

if not all(files.values()):
    print('缺 F-C0041 樣本檔，略過'); sys.exit(0)

class R:
    def __init__(self, b): self.content = b; self.status_code = 200
    def raise_for_status(self): pass
    def json(self): return json.loads(self.content.decode('utf-8'))

def fake_get(url, params=None, timeout=None):
    i = int(url.rsplit('-', 1)[-1])
    return R(open(files[i], 'rb').read())

fr.cwa_get = fake_get
iss = json.load(open(files[1], encoding='utf-8'))['cwaopendata']['Dataset']['DatasetInfo']['IssueTime']
iss_dt = fr._tpe_naive(iss)

fr.now_tpe_naive = lambda: datetime(2026, 11, 8, 12, 0)
segs = fr.fetch_typhoon_qpf()
ok(segs == [], f'發布 {iss}、現在 2026-11-08 → 過期不採用（實得 {len(segs)} 段）')

fr.now_tpe_naive = lambda: iss_dt.replace(hour=iss_dt.hour + 1)
segs = fr.fetch_typhoon_qpf()
ok(len(segs) == 8, f'發布後 1 小時 → 採用 8 段（實得 {len(segs)}）')
ok(all(len(s['points']) > 1000 for s in segs), '每段格點數 > 1000')

# 3. cwa_overlay：時段解析不到 → 不可落到「現在起第 i 段」
bad = [{'label': 'x', 'points': [(23.5, 121.0, 99.0)], 'start': ''}]
now = datetime(2026, 11, 8, 12)
q, qq, real, band, ow = fr.cwa_overlay('臺北市中正區', 23.5, 121.0, 64, {}, False, {}, bad,
                                       now, now.replace(hour=0))
ok(not real and not ow, f'解析不到時段的颱風段被跳過（實得覆寫 {ow}）')

print('\n全部通過' if not fails else f'\n失敗 {len(fails)} 項：{fails}')
sys.exit(1 if fails else 0)
