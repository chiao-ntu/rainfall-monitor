// CWA 兩種模式的守門（2026-11-08 使用者回報：切到 CWA 時地圖資料跑掉、
// 不是完全呈現氣象署資料；色塊要讀出數值作圖）。
//
//   ① CWA（純官方）：官方有發布的段＝可加量（qpf_cwa_q），未發布的段＝無資料，
//      不得混入任何模式／FORMOSA；視窗內只要有一段沒發布就不加總。
//   ② CWA+F：官方段＝官方值，其餘段＝FORMOSA。
//   ③ 地圖改為數值作圖：CWA 的填色必須等於「同一個數值」套雨量色階的結果。
//   ④ 過去日視窗在 CWA 模式下顯示觀測，與其他模式完全相同（先前被塗成今天第 0 段的色帶）。
//   ⑤ 切換順序（FORMOSA→CWA→過去→CWA+F→CWA）不影響結果（無殘留快取）。
//   ⑥ F-c 可把 CWA 列入加權；FORMOSA 的 CWA 權重照舊存在。
const puppeteer=require('puppeteer');
(async()=>{
 const b=await puppeteer.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
   args:['--no-sandbox','--disable-dev-shm-usage'],defaultViewport:{width:1400,height:880}});
 const pg=await b.newPage(); const errs=[];
 pg.on('pageerror',e=>errs.push(String(e).slice(0,200)));
 await pg.goto('http://127.0.0.1:8899/_local.html',{waitUntil:'networkidle2',timeout:120000});
 await new Promise(r=>setTimeout(r,6000));
 const R=await pg.evaluate(()=>{
  const fails=[], log=[];
  const ok=(c,m)=>{ if(!c) fails.push(m); log.push((c?'OK  ':'!!  ')+m); };
  const T=TOWNSHIPS.filter(t=>(t.band_segs||[]).length || (t.official_segs||[]).length);
  ok(T.length>100, `有 CWA 覆蓋的鄉鎮 ${T.length}`);
  const fillOf=t=>_townFill(t,false).fillColor;

  // ── ① 純官方 ──
  setModel('cwa'); setWin('fut6_2'); setMode('rain');
  let bad=0, n=0, leak=0;
  T.forEach(t=>{
    const cov=_cwaCoveredSegs(t), q=_cwaQArr(t), arr=getQpfArr(t,'qpf_cwa');
    for(let i=0;i<60;i++){
      const exp = (cov.has(i) && q[i]!=null) ? q[i] : null;
      if(arr[i]!==exp){ bad++; if(exp==null) leak++; }
    }
    n++;
  });
  ok(bad===0, `①純 CWA 陣列＝官方可加量、未發布段＝null（不符 ${bad}，其中混入非官方值 ${leak}）`);
  // 視窗內有未發布段 → 不加總
  const t0=T[0]; const cov0=_cwaCoveredSegs(t0);
  const lastCov=Math.max(...cov0);
  segFrom=lastCov; segTo=lastCov+1;
  const a1=getAccum(t0);
  ok(a1.totalRain===null, `①視窗跨過官方最後一段（段 ${lastCov}→${lastCov+1}）→ 無資料（實得 ${a1.totalRain}）`);
  // 第 3 天之後完全沒有官方資料
  setWin('day3');
  const nn=T.filter(t=>getAccum(t).totalRain!=null).length;
  ok(nn===0, `①第 3 天（官方未發布）不得有任何數值（實得 ${nn} 個鄉鎮有值）`);

  // ── ③ 數值作圖：填色＝同數值套雨量色階 ──
  setWin('fut6_2');
  let mis=0, numeric=0;
  T.forEach(t=>{
    const acc=getAccum(t);
    const exp = acc.totalRain==null ? '#FFFFFF' : rainColor(acc.totalRain, _rainScaleOf(acc));
    if(fillOf(t)!==exp) mis++;
    if(acc.totalRain!=null) numeric++;
  });
  ok(numeric>50 && mis===0, `③CWA 地圖以數值著色（${numeric} 個鄉鎮有數值，與色階不符 ${mis}）`);
  // 數值必須等於官方可加量之和
  let sumBad=0;
  T.forEach(t=>{
    const acc=getAccum(t), q=getQpfArr(t,'qpf_cwa');
    const s=[segFrom,segTo].reduce((a,_,k)=>a,0);
    let tot=0, has=true;
    for(let i=Math.max(0,segFrom);i<=segTo;i++){ if(q[i]==null) has=false; else tot+=q[i]; }
    const exp = has ? Math.round(tot*10)/10 : null;
    if(acc.totalRain!==exp) sumBad++;
  });
  ok(sumBad===0, `③地圖數值＝官方可加量逐段加總（不符 ${sumBad}）`);

  // ── ④ 過去日：CWA 與 FORMOSA 完全相同（都是觀測）──
  setWin('past1');
  const pastCwa=T.map(t=>[getAccum(t).totalRain, fillOf(t)]);
  setModel('blend');
  const pastBl=T.map(t=>[getAccum(t).totalRain, fillOf(t)]);
  const pd=pastCwa.filter((v,i)=>v[0]!==pastBl[i][0] || v[1]!==pastBl[i][1]).length;
  ok(pd===0, `④過去日在 CWA 與 FORMOSA 下相同（不同 ${pd}）`);

  // ── ② CWA+F ──
  setModel('cwaf'); setWin('fut6_2');
  let bad2=0;
  T.forEach(t=>{
    const pure=_cwaPureArr(t), bl=_blendQpf(t), arr=getQpfArr(t,'qpf_cwaf');
    for(let i=0;i<40;i++){
      const exp = pure[i]!=null ? pure[i] : (bl[i]!=null ? bl[i] : null);
      if(arr[i]!==exp) bad2++;
    }
  });
  ok(bad2===0, `②CWA+F：官方段＝官方值，其餘＝FORMOSA（不符 ${bad2}）`);
  setWin('day3');
  const nf=T.filter(t=>getAccum(t).totalRain!=null).length;
  ok(nf>50, `②CWA+F 第 3 天由 FORMOSA 補（${nf} 個鄉鎮有值）`);

  // ── ⑤ 切換順序不影響結果 ──
  setModel('cwa'); setWin('fut6_2');
  const A=T.map(t=>getAccum(t).totalRain);
  setModel('blend'); setWin('past1'); setModel('cwaf'); setWin('day3'); setModel('cwa'); setWin('fut6_2');
  const B=T.map(t=>getAccum(t).totalRain);
  const sd=A.filter((v,i)=>v!==B[i]).length;
  ok(sd===0, `⑤切換順序後 CWA 結果一致（不同 ${sd}）`);

  // ── ⑥ F-c 含 CWA；FORMOSA 的 CWA 權重存在 ──
  ok(FC_MODELS.some(([m])=>m==='cwa'), '⑥F-c 模式清單含 CWA');
  const cfg=_fcLoad();
  ok(FC_ZONES.every(z=>cfg[z] && cfg[z].cwa>0), `⑥F-c 各地形 CWA 起始權重 > 0（${FC_ZONES.map(z=>cfg[z]&&cfg[z].cwa).join('/')}）`);
  ok(typeof CWA_BLEND_W==='number' && CWA_BLEND_W>0, `⑥FORMOSA 的 CWA 權重倍率 ${CWA_BLEND_W}`);
  // F-c 只勾 CWA 時，官方段＝CWA 值
  const z=_townZone(t0)||''; const save=JSON.stringify(_fcCfg);
  FC_ZONES.forEach(zz=>{ Object.keys(_fcCfg[zz]).forEach(m=>_fcCfg[zz][m]=0); _fcCfg[zz].cwa=1; });
  const fcA=_fcQpf(t0), pure0=_cwaPureArr(t0);
  const fcBad=[...cov0].filter(i=>pure0[i]!=null && Math.abs(fcA[i]-pure0[i])>0.051).length;
  ok(fcBad===0, `⑥F-c 只勾 CWA → 官方段等於官方值（不符 ${fcBad}）`);
  _fcCfg=JSON.parse(save);
  setModel('blend');
  return {fails, log};
 });
 console.log(R.log.join('\n'));
 if(errs.length) console.log('\n*** pageerror ***\n'+errs.join('\n'));
 console.log(`\n${R.fails.length?'FAIL '+R.fails.length:'ALL PASS'} / ${R.log.length} 項`);
 await b.close();
 process.exit(R.fails.length||errs.length?1:0);
})();
