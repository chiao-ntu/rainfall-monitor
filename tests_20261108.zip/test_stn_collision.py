#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""驗證站名撞名不再污染 ETR2（臺中和平區 破百 vs 官網個位數 之根因）。

全臺有 6 組代表站「去尾英文字母後同名、實為不同機關的不同站」：
  武陵/武陵w、關山/關山w、南庄/南庄w、外大坪/外大坪w、寒溪/寒溪s、雙溪/雙溪tp
舊版無條件建立正規化鍵，使兩站塌成同一鍵，對站時可能取到另一站的值。
"""
import io, tempfile, json, os, sys, types
import tempfile
from datetime import datetime, timezone, timedelta
os.environ.setdefault('CWA_API_KEY', 'dummy')
import fetch_qpesums_hourly as H

fails = []
def chk(label, got, exp):
    ok = got == exp
    if not ok: fails.append(label)
    print(f"  {'OK ' if ok else '!! '}{label}: {got!r}" + ('' if ok else f"  期望 {exp!r}"))


class R:
    def __init__(s, o): s.status_code = 200; s.content = json.dumps(o).encode()


# ★ STRT 直接就是毫米
# 兩個「武陵」：氣象署武陵 35mm、水利署武陵w 380mm
DATA = [
    {"County": "臺中市", "Town": "和平區", "AlertValue": 350,
     "STName1": "武陵",  "STRT1": 35.0, "STName2": "德基", "STRT2": 12.0},
    {"County": "宜蘭縣", "Town": "大同鄉", "AlertValue": 400,
     "STName1": "武陵w", "STRT1": 380.0, "STName2": "土場", "STRT2": 20.0},
    # 不撞名者：正規化鍵應正常建立
    {"County": "南投縣", "Town": "仁愛鄉", "AlertValue": 400,
     "STName1": "廬山國小s", "STRT1": 44.0, "STName2": "奧萬大", "STRT2": 30.0},
]

H.requests = types.SimpleNamespace(get=lambda *a, **k: R(DATA))
out = H.fetch_swcb_hourly()

slope = '/mnt/user-data/uploads/slope_warning_stations.json'
print('=== 真實資料：同名不同站必須以地理位置區分 ===')
# ★ 使用者於 2026-08-26 自 API 實抓的原始資料（節錄）
REAL = [
 {"County":"臺中市","Town":"和平區","Vill":"平等里","DebrisNO":"中市DF037","AlertValue":350,
  "STID1":"A0F010","STName1":"武陵","STRT1":33.726505,
  "STID2":"C0F9Z0","STName2":"雪山東峰","STRT2":82.583374},
 {"County":"臺中市","Town":"和平區","Vill":"平等里","DebrisNO":"中市DF038","AlertValue":350,
  "STID1":"A0F010","STName1":"武陵","STRT1":33.726505,
  "STID2":"C0F9Z0","STName2":"雪山東峰","STRT2":82.583374},
 {"County":"臺東縣","Town":"延平鄉","Vill":"武陵村","DebrisNO":"東縣DF028","AlertValue":450,
  "STID1":"01S130","STName1":"武陵","STRT1":162,
  "STID2":"C0SA40","STName2":"瑞和","STRT2":0},
]
H.requests = types.SimpleNamespace(get=lambda *a, **k: R(REAL))
rl = H.fetch_swcb_hourly()
chk('STRT 即毫米，不做換算（臺中武陵 STID）', rl.get('A0F010'), 33.726505)
chk('臺東武陵 STID 各自獨立', rl.get('01S130'), 162.0)
chk('★同名多站 → 不建立站名鍵（避免覆蓋）', rl.get('武陵'), None)
chk('唯一站名仍可用站名對到', rl.get('雪山東峰'), 82.583374)
chk('地理索引：臺中和平的武陵', H.SWCB_BY_LOC.get(('臺中市','和平區','武陵')), 33.726505)
chk('地理索引：臺東延平的武陵', H.SWCB_BY_LOC.get(('臺東縣','延平鄉','武陵')), 162.0)

print('\n=== 聚合：和平區必須取 33.7 而非 162 ===')
if os.path.exists(slope):
    import shutil, tempfile
    from datetime import datetime
    tmp3 = tempfile.mkdtemp(); cwd3 = os.getcwd()
    shutil.copy(slope, tmp3); os.chdir(tmp3)
    H.SLOPE_WARN_FILE = 'slope_warning_stations.json'; H.ETR2_FILE = 'etr2_now.json'
    H.write_etr2_now(rl, datetime(2026, 8, 26, 12, 0))
    dd = json.load(io.open('etr2_now.json', encoding='utf-8'))
    hp3 = dd['townships'].get('臺中市和平區')
    print('  和平區:', json.dumps(hp3, ensure_ascii=False) if hp3 else '（無）')
    if hp3:
        chk('★和平區 ETR2 取臺中武陵 33.7', round(hp3['etr2'], 1), 33.7)
        pct3 = hp3['pct'] * 100
        print(f"  ETR2% = {pct3:.1f}%（誤用臺東 162 會是 {162/350*100:.0f}%）")
        if pct3 > 30: fails.append(f'和平區 ETR2% 仍偏高（{pct3:.1f}%）')
        else: print('  OK  與官網量級一致')
    os.chdir(cwd3); shutil.rmtree(tmp3, ignore_errors=True)
H.requests = types.SimpleNamespace(get=lambda *a, **k: R(DATA))
out = H.fetch_swcb_hourly()

print('=== 撞名站不得建立正規化鍵 ===')
chk('武陵 35mm', out.get('武陵'), 35.0)
chk('武陵w 380mm', out.get('武陵w'), 380.0)
# ★ 關鍵：正規化鍵「武陵」若被 武陵w 覆蓋，和平區就會拿到 380 而非 5
chk('★正規化鍵未被另一站污染', out.get('武陵'), 35.0)

print('\n=== 不撞名者仍建立正規化鍵（對站能力不受損）===')
chk('廬山國小s 44mm', out.get('廬山國小s'), 44.0)
chk('廬山國小（正規化）可對到', out.get('廬山國小'), 44.0)
chk('奧萬大 30mm', out.get('奧萬大'), 30.0)

print('\n=== 聚合後的鄉鎮值 ===')
# 用真實警戒表驗證和平區
if os.path.exists(slope):
    import shutil, tempfile
    tmp = tempfile.mkdtemp(); cwd = os.getcwd()
    shutil.copy(slope, tmp); os.chdir(tmp)
    H.SLOPE_WARN_FILE = 'slope_warning_stations.json'; H.ETR2_FILE = 'etr2_now.json'
    from datetime import datetime
    # 和平區 11 個單元，只給武陵有值（5mm / 警戒值350 = 1.4%）
    H.write_etr2_now({'武陵': 35.0, '武陵w': 380.0}, datetime(2026, 8, 20, 10, 0))
    d = json.load(io.open('etr2_now.json', encoding='utf-8'))
    hp = d['townships'].get('臺中市和平區')
    print('  臺中市和平區:', json.dumps(hp, ensure_ascii=False) if hp else '（無）')
    if hp:
        chk('★和平區取到武陵的 35mm 而非武陵w 的 380mm', hp['etr2'], 35.0)
        pct = hp['pct'] * 100
        print(f"  ETR2% = {pct:.1f}%（若誤用武陵w 會是 {380/hp['alert']*100:.0f}%）")
        if pct > 50: fails.append(f'和平區 ETR2% 仍異常偏高（{pct:.1f}%）')
        else: print('  OK  百分比回到合理範圍（不再破百）')
    os.chdir(cwd); shutil.rmtree(tmp, ignore_errors=True)
else:
    print('  （找不到 slope_warning_stations.json，略過聚合驗證）')

print('\n=== 量級防呆：單位錯誤時拒寫檔 ===')
if os.path.exists(slope):
    import shutil, tempfile
    from datetime import datetime
    tmp2 = tempfile.mkdtemp(); cwd2 = os.getcwd()
    shutil.copy(slope, tmp2); os.chdir(tmp2)
    H.SLOPE_WARN_FILE = 'slope_warning_stations.json'; H.ETR2_FILE = 'etr2_now.json'
    # 先寫一份正常的
    H.write_etr2_now({'武陵': 35.0}, datetime(2026, 8, 20, 10, 0))
    ok_exists = os.path.exists('etr2_now.json')
    before = io.open('etr2_now.json', encoding='utf-8').read() if ok_exists else ''
    # 再餵入「誤乘警戒值」的錯誤資料（全臺破萬%）
    bad = {}
    tw = json.load(io.open('slope_warning_stations.json', encoding='utf-8'))['townships']
    for regs in tw.values():
        for r in regs:
            bad[r['station']] = r['alert'] * 100.0        # 模擬放大 100 倍
    H.write_etr2_now(bad, datetime(2026, 8, 20, 11, 0))
    after = io.open('etr2_now.json', encoding='utf-8').read() if os.path.exists('etr2_now.json') else ''
    chk('★異常量級時不覆寫檔案（保留前一份）', after, before)
    os.chdir(cwd2); shutil.rmtree(tmp2, ignore_errors=True)


print('\n=== 稽核實測：5 個高風險鄉鎮必須取到正確的站 ===')
# ★ 2026-08-27 全臺稽核實測結果（30 個同名多站、5 個鄉鎮舊法接錯）
#   下列資料重現該 5 例的關鍵結構，確保地理對站能正確區分。
AUDIT = [
 # 關山：三個 STID，關山鎮與海端鄉各有自己的「關山」單元
 {"County":"臺東縣","Town":"關山鎮","AlertValue":500,
  "STID1":"C1O880","STName1":"關山","STRT1":139.0,
  "STID2":"81S570","STName2":"月眉國小s","STRT2":139.0},
 {"County":"臺東縣","Town":"海端鄉","AlertValue":450,
  "STID1":"C0S890","STName1":"關山","STRT1":153.9,
  "STID2":"81S900","STName2":"加拿國小s","STRT2":153.9},
 {"County":"高雄市","Town":"六龜區","AlertValue":250,
  "STID1":"01O760","STName1":"關山","STRT1":254.0,      # ← 舊法會用這個覆蓋上面兩個
  "STID2":"C1V340","STName2":"大津","STRT2":386.8},
 # 大坑：臺中北屯/潭子 與 花蓮壽豐 同名
 {"County":"臺中市","Town":"北屯區","AlertValue":500,
  "STID1":"C0F970","STName1":"大坑","STRT1":89.5,
  "STID2":"C0F970","STName2":"大坑","STRT2":89.5},
 {"County":"花蓮縣","Town":"壽豐鄉","AlertValue":400,
  "STID1":"C0T9E0","STName1":"大坑","STRT1":152.5,      # ← 舊法會用這個覆蓋臺中
  "STID2":"C0T870","STName2":"鯉魚潭","STRT2":224.6},
]
H.requests = types.SimpleNamespace(get=lambda *a, **k: R(AUDIT))
au = H.fetch_swcb_hourly()
chk('關山對應多 STID → 不建站名鍵', au.get('關山'), None)
chk('大坑對應多 STID → 不建站名鍵', au.get('大坑'), None)
chk('地理索引：關山鎮的關山', H.SWCB_BY_LOC.get(('臺東縣','關山鎮','關山')), 139.0)
chk('地理索引：海端鄉的關山', H.SWCB_BY_LOC.get(('臺東縣','海端鄉','關山')), 153.9)
chk('地理索引：六龜區的關山', H.SWCB_BY_LOC.get(('高雄市','六龜區','關山')), 254.0)
chk('地理索引：北屯區的大坑', H.SWCB_BY_LOC.get(('臺中市','北屯區','大坑')), 89.5)
chk('地理索引：壽豐鄉的大坑', H.SWCB_BY_LOC.get(('花蓮縣','壽豐鄉','大坑')), 152.5)

if os.path.exists(slope):
    import shutil, tempfile
    from datetime import datetime
    tmp4 = tempfile.mkdtemp(); cwd4 = os.getcwd()
    shutil.copy(slope, tmp4); os.chdir(tmp4)
    H.SLOPE_WARN_FILE = 'slope_warning_stations.json'; H.ETR2_FILE = 'etr2_now.json'
    H.write_etr2_now(au, datetime(2026, 8, 27, 12, 0))
    dd4 = json.load(io.open('etr2_now.json', encoding='utf-8'))['townships']
    for town, want_pct, want_mm in [('臺東縣關山鎮', 27.8, 139.0),
                                    ('臺東縣海端鄉', 34.2, 153.9),
                                    ('臺中市北屯區', 17.9, 89.5)]:
        r4 = dd4.get(town)
        got = round(r4['pct']*100, 1) if r4 else None
        ok = got is not None and abs(got - want_pct) < 0.6
        if not ok: fails.append(f'{town} ETR2% {got} ≠ 稽核值 {want_pct}')
        print(f"  {'OK ' if ok else '!! '}{town}: {got}%（稽核 {want_pct}%）"
              + (f" 站={r4['station']}" if r4 else ''))
    os.chdir(cwd4); shutil.rmtree(tmp4, ignore_errors=True)


print('\n=== 已知同名站清單須與實測一致 ===')
amb_file = '/home/claude/ambiguous_stations.json'
if not os.path.exists(amb_file):
    amb_file = 'ambiguous_stations.json'
if os.path.exists(amb_file):
    ref = json.load(io.open(amb_file, encoding='utf-8'))
    names = ref['ambiguous_names']
    print(f"  已知同名多站：{len(names)} 個（2026-08-27 全臺稽核實測）")
    chk('清單筆數為 30', len(names), 30)
    chk('關山對應 3 個 STID', len(names.get('關山', [])), 3)
    chk('武陵含臺中 A0F010', 'A0F010' in names.get('武陵', []), True)
    chk('武陵含臺東 01S130', '01S130' in names.get('武陵', []), True)
    # 已知接錯站的鄉鎮：虛增幅度需與紀錄一致
    for m in ref['_known_mismatched_townships']:
        gap = round(m['oldway_pct'] - m['correct_pct'], 1)
        print(f"  {m['township']}：正確 {m['correct_pct']}%、"
              f"舊法 {m['oldway_pct']}%（虛增 {gap}%）站={m['station']}")
        if gap <= 0:
            fails.append(f"{m['township']} 舊法未虛增，紀錄可能有誤")
    chk('已知受影響鄉鎮為 5 個', len(ref['_known_mismatched_townships']), 5)
else:
    print('  （找不到 ambiguous_stations.json，略過）')


print('\n=== 風力預報擷取（F-D0047）===')
# ★ 不以 ElementName 比對（實際字串未經證實），改認 WindSpeed/BeaufortScale 值鍵
import fetch_rainfall as FR
SAMPLE = {"records":{"Locations":[{"Location":[{
  "LocationName":"仁愛鄉",
  "WeatherElement":[
    {"ElementName":"溫度","Time":[
      {"DataTime":"2026-08-30T12:00:00+08:00","ElementValue":[{"Temperature":"22"}]}]},
    {"ElementName":"風速","Time":[
      {"DataTime":"2026-08-30T12:00:00+08:00",
       "ElementValue":[{"WindSpeed":"12","BeaufortScale":"6"}]},
      {"DataTime":"2026-08-30T15:00:00+08:00",
       "ElementValue":[{"WindSpeed":"18","BeaufortScale":"8"}]}]}]}]}]}}
class _R:
    status_code = 200
    def json(self): return SAMPLE
    def raise_for_status(self): pass
FR.requests = types.SimpleNamespace(get=lambda *a, **k: _R())
FR.WIND_FCST.clear()
FR.fetch_pop_county('南投縣', 'F-D0047-055', True)
w = FR.WIND_FCST.get('南投縣', {}).get('仁愛鄉', [])
chk('抓到兩段風力', len(w), 2)
chk('風速正確', [x['ws'] for x in w], [12.0, 18.0])
chk('蒲福風級正確', [x['bf'] for x in w], [6, 8])
chk('★溫度未被誤當風速', all(x['ws'] in (12.0, 18.0) for x in w), True)
chk('★逐3小時已補區間結束時間', w[0]['end'] != w[0]['start'], True)
print(f"  區間：{w[0]['start'][11:16]} → {w[0]['end'][11:16]}")


print('\n=== 離島風力：">= N" 格式與多時間點（真實檔案）===')
# ★ 使用者實抓的連江縣 F-D0047-081：風大時官方以 ">= 11" 表示，
#   且逐 3 小時資料只填 DataTime（StartTime 為空字串）。
#   這兩點先前各自造成：整筆丟棄、32 段併成 1 段。
_xml = 'F-D0047-081.xml'
if os.path.exists(_xml):
    import re as _re, xml.etree.ElementTree as _ET
    _raw = _re.sub(r'\sxmlns="[^"]+"', '', io.open(_xml, encoding='utf-8').read(), count=1)
    _root = _ET.fromstring(_raw)
    _locs = []
    for _loc in _root.iter('Location'):
        _wl = []
        for _we in _loc.findall('WeatherElement'):
            _ts = []
            for _t in _we.findall('Time'):
                _ev = _t.find('ElementValue')
                _evd = {c.tag: (c.text or '') for c in _ev} if _ev is not None else {}
                _ts.append({'DataTime': (_t.findtext('DataTime') or ''),
                            'StartTime': (_t.findtext('StartTime') or ''),
                            'EndTime': (_t.findtext('EndTime') or ''),
                            'ElementValue': [_evd]})
            _wl.append({'ElementName': _we.findtext('ElementName') or '', 'Time': _ts})
        _locs.append({'LocationName': _loc.findtext('LocationName') or '',
                      'WeatherElement': _wl})
    _SAMPLE = {'records': {'Locations': [{'Location': _locs}]}}
    class _RR:
        status_code = 200
        def json(self): return _SAMPLE
        def raise_for_status(self): pass
    FR.requests = types.SimpleNamespace(get=lambda *a, **k: _RR())
    FR.WIND_FCST.clear()
    FR.fetch_pop_county('連江縣', 'F-D0047-081', True)
    _w = FR.WIND_FCST.get('連江縣', {})
    chk('★連江縣四鄉皆有風力', sorted(_w.keys()),
        ['北竿鄉', '南竿鄉', '東引鄉', '莒光鄉'])
    _n = len(_w.get('南竿鄉', []))
    print(f"  南竿鄉 {_n} 段（檔案含 32 個時間點）")
    chk('★多時間點未被去重誤併', _n >= 30, True)
    chk('★">= 11" 解析為 11.0', _w['南竿鄉'][0]['ws'], 11.0)
    chk('★">= 6" 解析為 6 級', _w['南竿鄉'][0]['bf'], 6)
    chk('區間結束時間已補', _w['南竿鄉'][0]['end'] != _w['南竿鄉'][0]['start'], True)
else:
    print('  （找不到 F-D0047-081.xml，略過）')


print('\n=== 風力須涵蓋全臺 22 縣市（含無坡地警戒的離島）===')
# ★ 金門、澎湖、連江沒有坡地警戒站。若 counties_needed 沿用 alert_table 的
#   縣市集合，這三縣市的 PoP 與風力會完全不抓 —— 實測即為離島無風力的主因。
_src = io.open('fetch_rainfall.py', encoding='utf-8').read()
chk('端點表含 22 縣市', len(FR.COUNTY_EP_3D), 22)
for _c in ('金門縣', '澎湖縣', '連江縣'):
    chk(f'{_c} 有 3 天端點', bool(FR.COUNTY_EP_3D.get(_c)), True)
    chk(f'{_c} 有 7 天端點', bool(FR.COUNTY_EP_7D.get(_c)), True)
chk('連江 3D 端點為 081（與實測檔案相符）', FR.COUNTY_EP_3D['連江縣'], 'F-D0047-081')
chk('連江 7D 端點為 083（與實測檔案相符）', FR.COUNTY_EP_7D['連江縣'], 'F-D0047-083')
chk('★counties_needed 以端點表為底（不受坡地警戒縣市限制）',
    'counties_needed = set(COUNTY_EP_3D.keys())' in _src, True)
_bad = [c for c in FR.COUNTY_EP_3D
        if int(FR.COUNTY_EP_7D[c].split('-')[-1]) - int(FR.COUNTY_EP_3D[c].split('-')[-1]) != 2]
chk('3D/7D 端點編號規則一致', _bad, [])


print('\n=== 全臺打包檔：一次下載取代 44 次呼叫 ===')
# ★ 逐縣市呼叫時，任一縣市失敗該縣市即全無資料（離島尤其常見）。
#   打包檔只有一次成敗，可靠得多；解析共用 _extract_pop_wind，兩路徑不會分歧。
_zipf = 'F-D0047-093.zip'
if os.path.exists(_zipf):
    _raw = open(_zipf, 'rb').read()
    class _ZR:
        status_code = 200
        content = _raw
    FR.requests = types.SimpleNamespace(get=lambda *a, **k: _ZR())
    FR.WIND_FCST.clear()
    _res = FR.fetch_all_pop_bundle(set(FR.COUNTY_EP_3D.keys()))
    chk('打包路徑成功回傳', bool(_res), True)
    if _res:
        _p3, _p7 = _res
        _wn = sum(len(v) for v in FR.WIND_FCST.values())
        print(f"  PoP3d {len(_p3)} 鄉鎮、PoP7d {len(_p7)}、風力 {_wn} 鄉鎮")
        chk('★風力涵蓋全臺 368 鄉鎮', _wn, 368)
        chk('風力涵蓋 22 縣市', len(FR.WIND_FCST), 22)
        # ★ 改以「縣市+鄉鎮」為鍵後，368 個鄉鎮全數到齊（不再被同名覆蓋）
        _comp = [k for k in _p3 if any(k.startswith(c) for c in FR.COUNTY_EP_3D)]
        chk('★PoP 複合鍵涵蓋 368 鄉鎮', len(_comp), 368)
        # 同名鄉鎮必須各自取到自己的值
        from datetime import datetime as _dt
        _base = _dt(2026, 8, 28, 18, 0, 0)
        for _twn, _n in (('東區', 4), ('中正區', 2), ('北區', 3)):
            _vals = {}
            for _c in FR.COUNTY_EP_3D:
                if (_c + _twn) in _p3:
                    _vals[_c] = tuple(FR.get_pop_6h_series(_twn, _p3, _p7, _base,
                                                           county=_c)[:4])
            chk(f'{_twn} 出現在 {_n} 個縣市', len(_vals), _n)
            if len(_vals) > 1:
                print(f"  {_twn}：" + "、".join(f"{c}{list(v)}" for c, v in
                                                list(_vals.items())[:2]))
                if len(set(_vals.values())) == 1:
                    print(f"  （{_twn} 各縣市值恰好相同，無法據此判定，略過）")
                else:
                    print(f"  OK  {_twn} 各縣市取到不同值（未互相覆蓋）")
        chk('保留純鄉鎮名鍵以相容', ('東區' in _p3), True)
        for _c, _n in (('連江縣', 4), ('金門縣', 6), ('澎湖縣', 6)):
            chk(f'★{_c} 有風力（{_n} 鄉鎮）', len(FR.WIND_FCST.get(_c, {})), _n)
        # 逐時段數：打包檔為逐 3 小時
        _first = next(iter(FR.WIND_FCST['連江縣'].values()))
        chk('每鄉鎮有多個時段', len(_first) > 10, True)
    chk('解析共用同一函式（不分歧）',
        '_extract_pop_wind(raw, county, is_3day)' in
        io.open('fetch_rainfall.py', encoding='utf-8').read(), True)
    chk('打包失敗會退回逐縣市',
        'bundled = fetch_all_pop_bundle' in
        io.open('fetch_rainfall.py', encoding='utf-8').read(), True)
else:
    print('  （找不到 F-D0047-093.zip，略過）')


print('\n=== 波浪預報模式（F-A0020-001）===')
# ★ 改用波浪模式格點資料：0.1°格點、逐時、含浪高/浪向/週期。
#   先前 F-D0047-095/096 與 F-A0085-00x 皆非沿海預報（404 或寒害指數）。
_src4 = io.open('fetch_rainfall.py', encoding='utf-8').read()
chk('採用波浪模式端點', FR.WAVE_EP, 'F-A0020-001')
chk('限制時間步控制體積', FR.WAVE_STEPS, 24)
chk('讀沿海鄉鎮清單', FR.COASTAL_TOWNS_FILE, 'coastal_towns.json')
chk('★經 ProductURL 下載（直接要 ZIP 會 500）',
    'url = _resolve_product_url(WAVE_EP)' in _src4, True)
# ★ 檔案型產品必須走 fileapi：datastore 對這類 dataid 回 404（實測 2026-08-31）
chk('metadata 先試 fileapi', "f\"{FILEAPI}/{dataid}\"" in _src4, True)
chk('帶 downloadType=WEB', "'downloadType': 'WEB'" in _src4, True)
chk('備援也走 fileapi 不走 datastore',
    'r = cwa_get(f"{FILEAPI}/{WAVE_EP}"' in _src4, True)
chk('FILEAPI 於檔首定義', _src4.index('FILEAPI      =') < _src4.index('def _resolve_product_url'), True)

# 端到端：metadata 全 404 時，仍能由 fileapi 直接取得 zip
_wz = '/mnt/user-data/uploads/F-A0020-001.zip'
if os.path.exists(_wz) and os.path.exists('coastal_towns.json'):
    _raw = open(_wz, 'rb').read()
    def _mk4(url, **kw):
        class _R:
            status_code = 404 if kw.get('params', {}).get('format') == 'JSON' else 200
            content = _raw
            def json(self): raise ValueError('not json')
        return _R()
    FR.requests = types.SimpleNamespace(get=_mk4)
    _save = FR.WAVE_STEPS; FR.WAVE_STEPS = 4
    _w4 = FR.fetch_wave_forecast()
    FR.WAVE_STEPS = _save
    print(f"  端到端：{len(_w4)} 個沿海鄉鎮")
    chk('★metadata 404 時仍取得浪高', len(_w4) >= 80, True)
    if _w4:
        _s4 = next(iter(_w4.values()))[0]
        chk('含浪高值', _s4['wave'] is not None, True)
        chk('含浪向', _s4['dir'] is not None, True)
        chk('含週期', _s4['period'] is not None, True)
chk('打包預報同樣經 ProductURL',
    "_burl = _resolve_product_url('F-D0047-093')" in _src4, True)

# ProductURL 解析器：對兩種 metadata 結構都須有效
for _name, _meta, _want in [
    ('ProductURL 大寫',
     {"cwaopendata":{"Resources":{"Resource":{"ProductURL":"https://x/a.zip"}}}}, 'https://x/a.zip'),
    ('uri 小寫',
     {"cwaopendata":{"dataset":{"resource":{"uri":"https://y/b.zip"}}}}, 'https://y/b.zip'),
]:
    class _MR:
        status_code = 200
        def __init__(self, m): self._m = m
        def json(self): return self._m
    FR.requests = types.SimpleNamespace(get=lambda *a, _m=_meta, **k: _MR(_m))
    chk(f'解析 {_name}', FR._resolve_product_url('X'), _want)


print('\n=== 颱風格點 QPF（F-C0041）解析修正 ===')
# ★ 舊寫法有兩個 bug：用 records.dataset（實際是 cwaopendata.Dataset）、
#   依換行切列（實際是 130×130 攤平的 16,900 個逗號分隔值）。
#   兩者都會讓颱風期間拿不到格點 —— 而那正是最需要精細預報的時候。
_qf = [f'/mnt/user-data/uploads/F-C0041-{n:03d}.json' for n in range(1, 9)]
if all(os.path.exists(f) for f in _qf):
    _qd = [json.load(io.open(f, encoding='utf-8')) for f in _qf]
    _qit = iter(_qd)
    def _mkq(*a, **k):
        class _R:
            status_code = 200
            def raise_for_status(self): pass
            def json(self): return next(_qit)
        return _R()
    FR.requests = types.SimpleNamespace(get=_mkq)
    #  ★ 2026-11-08 起 F-C0041 有發布新鮮度門檻（>12 小時不採用）；
    #    這裡驗的是「解析」，把現在時間固定在該報發布後 1 小時。
    _iss = FR._tpe_naive(_qd[0]['cwaopendata']['Dataset']['DatasetInfo']['IssueTime'])
    FR.now_tpe_naive = lambda: _iss + FR.timedelta(hours=1)
    _segs = FR.fetch_typhoon_qpf()
    chk('★解析出 8 段（48 小時）', len(_segs), 8)
    if _segs:
        _p = _segs[0]['points']
        chk('臺灣範圍格點數合理', 8000 < len(_p) < 11000, True)
        chk('首段有起始時間', _segs[0]['start'][:4], '2026')
        _mx = max(_p, key=lambda x: x[2])
        print(f"  首段最大 {_mx[2]:.1f}mm @ {_mx[0]:.2f}N {_mx[1]:.2f}E")
        chk('數值合理（非全零）', _mx[2] > 10, True)
        chk('緯度在臺灣範圍', 21.5 <= _mx[0] <= 26.5, True)

print('\n=== 預報員研判雨量區間（F-C0034）===')
_t24 = '/mnt/user-data/uploads/24hPrecipTable.xml'
_tal = '/mnt/user-data/uploads/AllPrecipTable.xml'
if os.path.exists(_t24) and os.path.exists(_tal):
    _tb = {'F-C0034-006': open(_t24, 'rb').read(),
           'F-C0034-007': open(_tal, 'rb').read()}
    _st = {'ep': None}
    def _mkt(url, **k):
        class _R:
            status_code = 200
            def json(self):
                _st['ep'] = url.rsplit('/', 1)[-1]
                return {"cwaopendata": {"Dataset": {"Resource":
                        {"ProductURL": "https://x/" + _st['ep']}}}}
            @property
            def content(self): return _tb.get(_st['ep'], b'')
        return _R()
    FR.requests = types.SimpleNamespace(get=_mkt)
    _fp = FR.fetch_forecaster_precip()
    chk('取得 24h 與總雨量兩份', sorted(_fp.keys()), ['24h', 'total'])
    if '24h' in _fp:
        _a = _fp['24h']['areas']
        chk('地區數', len(_a), 24)
        chk('★區分平地與山區', 'mountain' in _a.get('臺北市', {}), True)
        chk('基隆僅平地', list(_a.get('基隆市', {}).keys()), ['flat'])
        _pt = _a.get('屏東縣', {}).get('mountain', {})
        print(f"  屏東山區 24h {_pt.get('lo')}-{_pt.get('hi')}mm、"
              f"總雨量 {_fp['total']['areas']['屏東縣']['mountain']['hi']}mm")
        chk('屏東山區有數值', _pt.get('hi', 0) > 0, True)
        chk('總雨量高於24h',
            _fp['total']['areas']['屏東縣']['mountain']['hi'] >= _pt.get('hi', 0), True)
    chk('★不限颱風（豪雨事件亦發布）', '豪雨事件' in _fp['24h']['title'], True)
    _src5 = io.open('fetch_rainfall.py', encoding='utf-8').read()
    chk('已處理 xsi 命名空間前綴', '帶 xsi: 命名空間前綴' in _src5, True)
    chk('輸出含 forecaster_precip', "'forecaster_precip': fc_precip" in _src5, True)
    chk('★載明不用於 ETR2 判定', '不用於 ETR2 警戒判定' in _src5, True)


print('\n=== 抗故障：殘缺資料不得覆蓋好資料 ===')
# ★ 實測 2026-09-01：CWA 開放資料大規模連線失敗，該輪 ETR2 由 156 掉到 0，
#   但 data.json 仍照常寫出，等於用殘缺資料覆蓋可用資料 ——
#   對防災系統而言比「不更新」更危險。
_src6 = io.open('fetch_rainfall.py', encoding='utf-8').read()
chk('★寫檔前有健全性檢查', '中止寫檔：資料明顯退化' in _src6, True)
chk('★用絕對門檻（非僅相對比較）', 'ETR2 鄉鎮數過低' in _src6, True)
chk('觀測全失效時中止', '本輪未取得任何觀測站資料' in _src6, True)
chk('PoP 覆蓋率把關', 'PoP 覆蓋率過低' in _src6, True)
chk('風力覆蓋率把關', '風力預報覆蓋率過低' in _src6, True)
chk('說明壞資料會變新常態', '壞資料反而變成新常態' in _src6, True)

# 實測判斷行為（含連兩輪失敗的實際情境）
import textwrap as _tw
# 只取「守衛判斷」那段（逐層保留在其前，需另行測試）
_i = _src6.index('    _cur_etr2 = sum(1 for t in out_towns'); _j = _src6.index('    if _abort:')
_snip = _tw.dedent(_src6[_i:_j])
def _guard(cur, prev, sta, pop, wind):
    def _ne(d):
        return sum(1 for t in (d.get('townships') or [])
                   if t.get('etr2_pct') is not None) if d else 0
    _ns = {'_n_etr2': _ne, 'out_towns': [{'etr2_pct': 1.0} for _ in range(cur)],
           '_prev': {'townships': [{'etr2_pct': 1.0} for _ in range(prev)]} if prev is not None else None,
           'alert_table': {i: 1 for i in range(159)},
           'stations': [1] * sta, 'pop3d': {i: 1 for i in range(pop)},
           'WIND_FCST': {'A': {i: 1 for i in range(wind)}}, '_abort': []}
    exec(_snip, {}, _ns)
    return _ns['_abort']
chk('正常資料放行', _guard(156, 156, 1300, 725, 368), [])
chk('★觀測全失敗中止', len(_guard(0, 156, 0, 725, 368)) > 0, True)
chk('★連兩輪失敗仍中止（壞資料不得成為基準）',
    len(_guard(0, 0, 0, 186, 127)) > 0, True)
chk('PoP 不足中止', len(_guard(156, 156, 1300, 186, 368)) > 0, True)
chk('輕微波動放行', _guard(120, 156, 1300, 700, 360), [])

print('\n=== 抗故障：熔斷 ===')
chk('提供熔斷機制', '_CWA_TRIPPED' in _src6, True)
chk('熔斷門檻已放寬（官方資料無可取代）', '_CWA_TRIP_AT     = 25' in _src6, True)
chk('★冷卻後自動恢復而非整輪放棄', '_CWA_COOLDOWN' in _src6, True)
chk('成功即重置連續失敗', '_CWA_FAIL_STREAK[0] = 0' in _src6, True)
chk('說明為何要快速失敗', '繼續苦等沒有意義' in _src6, True)
chk('說明比不更新更危險', '比「不更新」更危險' in _src6, True)

print('\n=== 抗故障：CWA 請求節流 ===')
chk('提供節流函式', 'def cwa_get(url, **kw):' in _src6, True)
chk('僅對 CWA 主機節流', "'opendata.cwa.gov.tw' in url" in _src6, True)
chk('使用 Session 重用連線', 'requests.Session()' in _src6, True)
chk('節流間隔已設定', '_CWA_MIN_GAP  = 0.35' in _src6, True)
chk('尊重測試替換的 requests', "getattr(requests, '__name__', '') == 'requests'" in _src6, True)
_n_cwa = _src6.count('cwa_get(')
_n_raw = _src6.count('requests.get(')
print(f'  呼叫點：cwa_get {_n_cwa-1} 處、原生 requests.get {_n_raw} 處')
chk('★呼叫點已全面改用節流版', _n_raw, 1)


print('\n=== 誤差追蹤（CMPF 第二階段）===')
# ★ 對應 NOAA National Blend of Models 的做法：以觀測校正各模式，
#   並依地形分群（NBM 稱 supplemental locations）。現階段只累積不回饋。
_tf = '/home/claude/terrain_zones_official.json'
if os.path.exists(_tf):
    _zn = json.load(io.open(_tf, encoding='utf-8'))['zones']
    _now = datetime.now(timezone.utc) + timedelta(hours=8)
    _tw = []
    for _k, _z in list(_zn.items())[:80]:
        if _z == '山區':   _o, _m = 120.0, 80.0     # 模式低估
        elif _z == '平地': _o, _m = 30.0, 50.0      # 模式高估
        else:               _o, _m = 60.0, 60.0     # 準確
        _tw.append({'county': _k[:3], 'township': _k[3:],
                    'daily_rain': [0.0, _o] + [0.0] * 13,
                    'model_yday': {'best': _m, 'ecmwf': _m, 'gfs': _m, 'icon': _m}})
    _cwd = os.getcwd()
    _tmp = tempfile.mkdtemp(); os.chdir(_tmp)
    try:
        _sk = FR.update_model_skill(_tw, _zn, _now)
        chk('寫出誤差追蹤檔', os.path.exists(FR.SKILL_FILE), True)
        _sm = FR.summarize_model_skill(_sk, _now)
        chk('★分地形統計', sorted(_sm.keys()) == sorted(set(
            _z for _k, _z in list(_zn.items())[:80])), True)
        _mt = _sm.get('山區', {}).get('best', {}).get('short', {})
        _pl = _sm.get('平地', {}).get('best', {}).get('short', {})
        print(f"  山區偏差比 {_mt.get('bias')}（模式低估）、"
              f"平地 {_pl.get('bias')}（模式高估）")
        chk('★山區偏差比 >1（正確識別低估）', _mt.get('bias', 0) > 1.2, True)
        chk('★平地偏差比 <1（正確識別高估）', 0 < _pl.get('bias', 9) < 0.8, True)
        chk('含 MAE', _mt.get('mae', 0) > 0, True)
        chk('記錄樣本數', _mt.get('n', 0) > 0, True)
        # 以下兩項各自用乾淨目錄，避免沿用前面已寫入的同日記錄
        _yk = (_now - timedelta(days=1)).strftime('%Y-%m-%d')
        # 無雨日不列入（比值無意義）
        os.chdir(tempfile.mkdtemp())
        _dry = [{'county': '南投縣', 'township': '仁愛鄉',
                 'daily_rain': [0.0, 2.0] + [0.0] * 13,
                 'model_yday': {'best': 1.0}}]
        _sk2 = FR.update_model_skill(_dry, {'南投縣仁愛鄉': '山區'}, _now)
        chk('★無雨日不計入（避免稀釋偏差）',
            (_sk2.get('days') or {}).get(_yk, {}), {})
        # 推估補值的鄉鎮不列入校驗
        os.chdir(tempfile.mkdtemp())
        _est = [{'county': '高雄市', 'township': '鹽埕區', 'obs_src': 'neighbor',
                 'daily_rain': [0.0, 100.0] + [0.0] * 13,
                 'model_yday': {'best': 50.0}}]
        _sk3 = FR.update_model_skill(_est, {'高雄市鹽埕區': '沿海地區'}, _now)
        chk('★推估值不列入校驗',
            (_sk3.get('days') or {}).get(_yk, {}), {})
    finally:
        os.chdir(_cwd)
    _src7 = io.open('fetch_rainfall.py', encoding='utf-8').read()
    chk('短期7天/長期30天分開統計', "('short', 7), ('long', 30)" in _src7, True)
    chk('保留 45 天樣本', 'SKILL_KEEP_DAYS = 45' in _src7, True)
    chk('四模式昨日回算', 'def fetch_models_yesterday' in _src7, True)
    chk('輸出含 model_skill', "output['model_skill']" in _src7, True)
    chk('★現階段不回饋修正', '現階段只累積與呈現，不回饋修正預測' in _src7, True)


print('\n=== 靜態檢查：未定義名稱 ===')
# ★ 實測 2026-09-02：新增測站座標時把參數名寫成 stations（實為 all_stations），
#   語法正確、compile 也過，但執行到才 NameError 而中斷整輪。
#   symtable 能在不執行的情況下抓出這類錯誤，故納入常態檢查。
import symtable as _symtable, builtins as _builtins
for _f in ('fetch_rainfall.py', 'fetch_qpesums_hourly.py'):
    if not os.path.exists(_f):
        continue
    _src = io.open(_f, encoding='utf-8').read()
    _st = _symtable.symtable(_src, _f, 'exec')
    _g = set(_st.get_identifiers()) | set(dir(_builtins))
    _bad = []
    def _walk(tab, path=''):
        for sym in tab.get_symbols():
            n = sym.get_name()
            if (sym.is_referenced() and not sym.is_assigned()
                    and not sym.is_parameter() and not sym.is_global()
                    and not sym.is_imported() and not sym.is_free()
                    and n not in _g):
                _bad.append(f'{path or tab.get_name()}() → {n}')
        for ch in tab.get_children():
            _walk(ch, (path + '/' + ch.get_name()) if path else ch.get_name())
    _walk(_st)
    if _bad:
        print(f'  {_f} 未定義名稱：')
        for b in _bad[:10]:
            print(f'    {b}')
    chk(f'{_f} 無未定義名稱', _bad, [])


print('\n=== 測站座標與海拔（兩條路徑一致）===')
FR.STATION_ELEV = {'C0H9A0': 2100.5}
_ex = [{'name': '翠峰', 'alert_val': 200, 'village': '某村'}]
_as = {'C0H9A0': {'name': '翠峰', 'lat': 24.09, 'lng': 121.17}}
_r1 = FR.enrich_stations_with_etr2(
    _ex, {'station_etr2': {'C0H9A0': 150.0}, 'stations': ['C0H9A0'],
          'station_daily': {'C0H9A0': [12.0] + [0.0] * 14}}, _as, 200)[0]
chk('★正常路徑帶 sid', _r1.get('sid'), 'C0H9A0')
chk('正常路徑帶座標', [_r1.get('lat'), _r1.get('lng')], [24.09, 121.17])
chk('★正常路徑帶海拔', _r1.get('elev'), 2100.5)
chk('ETR2% 仍正確', _r1.get('etr2_pct'), 0.75)
# 無觀測站的早退路徑（欄位須齊全，否則前端取不到）
_r2 = FR.enrich_stations_with_etr2(_ex, {}, _as, 200)[0]
chk('★早退路徑亦有 sid 欄位', 'sid' in _r2, True)
chk('★早退路徑亦有 elev 欄位', 'elev' in _r2, True)
chk('兩條路徑欄位一致', sorted(_r1.keys()), sorted(_r2.keys()))
FR.STATION_ELEV = {}


print('\n=== 測站海拔與座標（官方欄位）===')
# ★ CWA 觀測站資料本身就有 StationAltitude 與 WGS84 座標，
#   不需再用 DTM 推算；且一站有 TWD67／WGS84 兩組座標，
#   取錯會整批偏移約 800m。
_of = '/mnt/user-data/uploads/O-A0002-001.json'
if os.path.exists(_of):
    _raw = json.load(io.open(_of, encoding='utf-8'))
    class _OR:
        status_code = 200
        def json(self): return _raw
        def raise_for_status(self): pass
    FR.requests = types.SimpleNamespace(get=lambda *a, **k: _OR())
    _st = FR.fetch_obs()
    chk('★解析出測站（支援兩種外層）', len(_st) > 1000, True)
    _alt = [v['alt'] for v in _st.values() if isinstance(v, dict) and v.get('alt') is not None]
    print(f"  {len(_st)} 站，有海拔 {len(_alt)}，範圍 {min(_alt):.0f}~{max(_alt):.0f}m")
    chk('★全數取得官方海拔', len(_alt), len(_st))
    chk('海拔範圍合理（含玉山級）', max(_alt) > 3000, True)
    # WGS84：臺灣本島經度應在 119.9~122.1
    _lngs = [v['lng'] for v in _st.values() if isinstance(v, dict) and v.get('lng')]
    _lats = [v['lat'] for v in _st.values() if isinstance(v, dict) and v.get('lat')]
    # 範圍須含東沙島(116.73E/20.70N)與馬祖東引(26.36N)等離島測站
    print(f"  經度 {min(_lngs):.2f}~{max(_lngs):.2f}、緯度 {min(_lats):.2f}~{max(_lats):.2f}")
    chk('★座標為 WGS84（經度合理）', 116 < min(_lngs) and max(_lngs) < 123, True)
    chk('緯度合理', 20 < min(_lats) and max(_lats) < 26.5, True)
    # 抽驗一個已知站：本島測站不得落在 TWD67 位置（差約 0.008 度）
    _n99 = next((v for v in _st.values()
                 if isinstance(v, dict) and v.get('name') == '九份二山'), None)
    if _n99:
        print(f"  九份二山 {_n99['lat']:.4f}N {_n99['lng']:.4f}E 海拔 {_n99['alt']:.0f}m")
        chk('★抽驗站座標正確', abs(_n99['lat'] - 23.962) < 0.01, True)
    _src8 = io.open('fetch_rainfall.py', encoding='utf-8').read()
    chk('明確取 WGS84', "!= 'WGS84'" in _src8, True)
    chk('說明取錯會偏移', '兩者在臺灣差約 800m' in _src8, True)
    chk('官方海拔優先於 DTM', "_elev = _sinfo.get('alt')" in _src8, True)
    chk('支援 cwaopendata 外層', "(raw.get('cwaopendata') or {}).get('dataset')" in _src8, True)


print('\n=== 全臺測站清單輸出 ===')
# ★ townships[].stations 只含警戒表的站，站名比對不到就沒座標
#   （實測 514/891 無座標）；測站圖層需要完整清單，故另行輸出 all_stations。
_src9 = io.open('fetch_rainfall.py', encoding='utf-8').read()
chk('★輸出全臺測站清單', "'all_stations': all_stations_out" in _src9, True)
chk('只留必要欄位（控制檔案大小）', "'la': round(_v['lat'], 5)" in _src9, True)
chk('含海拔', "'e': _v.get('alt')" in _src9, True)
chk('含縣市鄉鎮', "'c': _v.get('county', '')" in _src9, True)
chk('說明為何需要', '實測 514/891 無座標' in _src9, True)
_srcA = io.open('index.html', encoding='utf-8').read()
chk('★前端優先用完整清單', 'const ALL = window.ALL_STATIONS || null;' in _srcA, True)
chk('地形圖層 z-index 夾在正確位置',
    "map.getPane('terrainPane').style.zIndex = 392;" in _srcA, True)
chk('說明只有顏色變淺的成因', '那正是「只有顏色變淺」的成因' in _srcA, True)


print('\n=== 雷達定量降雨格點（O-B0045）===')
# ★ 原「QPESUMS 停用」其實是換了 dataid；441×561 格點、1.4km 解析度。
#   用鄉鎮多邊形聚合取代質心單點 —— 質心取樣時實測約 60% 鄉鎮為 null。
_rf = '/mnt/user-data/uploads/O-B0045-001.xml'
if os.path.exists(_rf) and os.path.exists('town_polys.json'):
    _rraw = open(_rf, 'rb').read()
    class _RR:
        status_code = 200; content = _rraw
    FR.cwa_get = lambda *a, **k: _RR()
    _v, _m = FR.fetch_radar_grid('O-B0045-001', '雷達過去1小時')
    chk('★解析格點', len(_v) if _v else 0, 441 * 561)
    chk('格點規格正確', [_m['nx'], _m['ny'], _m['res']], [441, 561, 0.0125])
    chk('起點為東經118/北緯20', [_m['lon0'], _m['lat0']], [118.0, 20.0])
    _pl = json.load(io.open('town_polys.json', encoding='utf-8'))
    _pv = {k: (x[0], x[1], x[2], x[3], x[4]) for k, x in _pl.items()}
    _agg = FR.radar_to_towns(_v, _m, _pv)
    chk('★多邊形聚合涵蓋率 >95%', len(_agg) / len(_pv) > 0.95, True)
    _avg = sum(x['n'] for x in _agg.values()) / max(1, len(_agg))
    print(f"  平均每鄉鎮 {_avg:.0f} 格（質心法只有 1 格）")
    chk('每鄉鎮多格取樣', _avg > 20, True)
    chk('含平均與最大', sorted(list(_agg.values())[0].keys()), ['max', 'mean', 'n'])
    # 無效值 -1 不得計入
    chk('★排除無效值', all(x['mean'] >= 0 for x in _agg.values()), True)
    _srcB = io.open('fetch_rainfall.py', encoding='utf-8').read()
    chk('輸出 radar_qpe', "'radar_qpe': radar_qpe" in _srcB, True)
    chk('輸出未來1小時', "'radar_qpf_grid': radar_qpf_grid" in _srcB, True)
    chk('說明質心法的問題', '實測約 60% 鄉鎮為空' in _srcB, True)


print('\n=== 模式升級：IFS HRES 9km 與 AI 模式 ===')
# ★ ecmwf_ifs（IFS HRES）是 ECMWF 官方物理模式，非 AI、非 Open-Meteo 加工。
#   9km vs 0.25°(25km)、前90h原生逐時、無 open-data 的 2 小時延遲 → 純升級。
_srcC = io.open('fetch_rainfall.py', encoding='utf-8').read()
chk('★預設改用 IFS HRES', "om_all.get('ecmwf_ifs') or om_all.get('ecmwf_ifs025'" in _srcC, True)
chk('qpf_ecmwf 取 IFS HRES', "qpf_ecmwf = get_qpf_model('ecmwf_ifs')" in _srcC, True)
chk('★IFS HRES 不可用時退回 0.25°', 'IFS HRES 無回應 → 退回 ECMWF IFS 0.25°' in _srcC, True)
chk('物理與 AI 分列', "OM_PHYSICAL = " in _srcC and "OM_AI       = " in _srcC, True)
chk('AI 模式為 AIFS 與 GraphCast',
    "OM_AI       = ['ecmwf_aifs025_single', 'gfs_graphcast025']" in _srcC, True)
chk('含 JMA', "'jma_seamless'" in _srcC, True)
chk('★保留逐時資料', "result_hourly[key]" in _srcC, True)
chk('輸出逐時欄位', "'hourly_ifs':" in _srcC, True)
chk('新模式進輸出', "'qpf_aifs':" in _srcC and "'qpf_gc':" in _srcC, True)
chk('誤差追蹤含 AI 模式', "'aifs': 'ecmwf_aifs025_single'" in _srcC, True)
_srcD = io.open('index.html', encoding='utf-8').read()
chk('★AI 模式獨立按鈕', 'id="mAifs"' in _srcD and 'id="mGc"' in _srcD, True)
chk('AI 按鈕視覺區分（紫）', "border-color:#7a5a9a" in _srcD, True)
chk('★融合含全部七個模式',
    "['best', 'ecmwf', 'gfs', 'icon', 'jma', 'aifs', 'gc']" in _srcD, True)
chk('★AI 偏差上限放寬至 3.0', "const cap = AI_MODELS.has(m) ? 3.0 : 2.0;" in _srcD, True)
chk('說明 AI 低估傾向', '對極端降雨傾向低估' in _srcD, True)
chk('情境編輯器含新模式', "aifs:'AIFS(AI)'" in _srcD, True)

print('\n全部通過' if not fails else f'\n失敗 {len(fails)} 項：{fails}')
sys.exit(1 if fails else 0)
