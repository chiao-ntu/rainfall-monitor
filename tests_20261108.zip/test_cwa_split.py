"""CWA 色塊窗逐小時分配（2026-11-08，使用者要求時間「越準越細越好」）。

舊法把 12 小時窗吸附到 6 小時段邊界（23 時→00 時、08 時→06 時），最多錯位 2 小時。
  1. 23 時那一報：今天日量＝官方 00~24 時（不再是前一天 23 時起）。
  2. 雨量守恆：所有段的可加量總和＝各窗上界總和（扣掉落在今天 00 時之前的小時）。
  3. 加強作業 08 時那一報：06~12 段只拿到 08~12 的 4 小時。
  4. 段中間缺小時 → 不算有值；預報終點只容許最後 1 小時。
  5. 發布班次由官方 Sent 推定：11:18 → 11 時；08:18 → 08 時；23:40 → 23 時。
"""
import os, sys
os.environ.setdefault('CWA_API_KEY', 'dummy')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fetch_rainfall as fr
from datetime import datetime, timedelta
fails = []
def ok(c, m):
    print(('OK  ' if c else '!!  ') + m)
    if not c: fails.append(m)

T0 = datetime(2026, 11, 8)          # 今天 00 時
K = '臺北市中正區'
hi = fr.qpf_band_hi
def wins(issue, vals):
    return [{'start': issue + timedelta(hours=12*k), 'end': issue + timedelta(hours=12*k+12),
             'vals': {K: v}} for k, v in enumerate(vals)]

# 1. 23 時那一報（前一天 23 時起 4 窗）
W = wins(datetime(2026, 11, 7, 23), [10, 5, 20, 2])
b, q = fr.cwa_split_windows(K, W, T0, 64)
day0 = sum(q.get(i, 0) for i in range(0, 4))
exp0 = hi(10) * 11/12 + hi(5) * 12/12 + hi(20) * 1/12     # 00-11 窗A、11-23 窗B、23-24 窗C
ok(abs(day0 - exp0) < 0.05, f'①今天日量＝官方 00~24 時 {day0:.2f}（應 {exp0:.2f}）')
ok(all(i in q for i in range(0, 8)), f'①今天與明天 8 段都有官方值（容許最後 1 小時）：{sorted(q)}')
# 2. 守恆
tot = sum(q.values())
expt = sum(hi(v) for v in (10, 5, 20, 2)) - hi(10) * 1/12          # 前一天 23-24 不在今天
ok(abs(tot - expt) < 0.05, f'②雨量守恆 {tot:.2f}（應 {expt:.2f}）')
# 3. 加強作業 08 時
W8 = wins(datetime(2026, 11, 8, 8), [30, 0.5, 0.5, 0.5])
b8, q8 = fr.cwa_split_windows(K, W8, T0, 64)
ok(1 in q8 and abs(q8[1] - hi(30) * 4/12) < 0.02, f'③08 時那一報：06~12 段＝4 小時份 {q8.get(1)}（應 {hi(30)*4/12:.2f}）')
ok(0 not in q8, '③發布前的 00~06 段不算有官方值')
# 4. 中間缺一窗的值 → 不算有值
W4 = wins(datetime(2026, 11, 7, 23), [10, 5, 20, 2]); W4[1]['vals'] = {}
b4, q4 = fr.cwa_split_windows(K, W4, T0, 64)
ok(1 not in q4 and 2 not in q4, f'④中間缺窗 → 涉及的段不算有值：{sorted(q4)}')
W5 = wins(datetime(2026, 11, 7, 23), [10, 5, 20]);   # 只有 3 窗：終點明天 11 時
b5, q5 = fr.cwa_split_windows(K, W5, T0, 64)
ok(5 in q5 and 6 not in q5, f'④終點只缺 1 小時的段容許、其後不算：{sorted(q5)}')
W6 = [{'start': datetime(2026, 11, 8, 2), 'end': datetime(2026, 11, 8, 10), 'vals': {K: 10}}]
b6, q6 = fr.cwa_split_windows(K, W6, T0, 64)
ok(1 not in q6, f'④終點缺 2 小時（06~12 段只到 10 時）→ 不算有值：{sorted(q6)}')
# 5. Sent → 發布班次
cases = [('2026-09-01T11:18:00+08:00', 11), ('2026-11-08T08:18:00+08:00', 8),
         ('2026-11-08T23:40:00+08:00', 23), ('2026-11-08T00:10:00+08:00', 23)]
for s_, h in cases:
    r = fr.cwa_issue_slot(s_)
    ok(r is not None and r.hour == h, f'⑤Sent {s_[11:16]} → {r:%m/%d %H}時（應 {h} 時）')
ok(fr.cwa_issue_slot('') is None, '⑤Sent 不明 → None（退回舊法）')

print('\n全部通過' if not fails else f'\n失敗 {len(fails)} 項：{fails}')
sys.exit(1 if fails else 0)
