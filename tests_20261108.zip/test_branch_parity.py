"""靜態表／非靜態表兩條鄉鎮分支的欄位一致性守門（2026-11-08 事故）。

事故：非靜態表 209 個鄉鎮（全臺 57%）取 ECMWF 用的是舊鍵 'ecmwf_ifs025'
（主抓取早已改為 'ecmwf_ifs'，舊鍵只在失敗時才抓）→ ECMWF 永遠是空；
JMA／AIFS／GraphCast 欄位更是整個沒寫出。FORMOSA 在大半地圖上少了三個主力成員，
log 只印「ecmwf_ifs025: 209 缺」，看起來像抓取失敗而非程式錯誤。

守門內容（純原始碼分析，不需網路）：
  1. 兩個 out_towns.append({...}) 的模式欄位（qpf_*/maxh_*/warn_seg_*/hourly_ifs）必須一致。
  2. get_qpf_model／get_ns_qpf／get_*_maxh 取用的模式鍵必須是本輪實際會抓的模式。
  3. 'ecmwf_ifs025' 只能出現在「'ecmwf_ifs' 之後的退路」位置。
"""
import ast, re, sys, os
SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fetch_rainfall.py')
src = open(SRC, encoding='utf-8').read()
tree = ast.parse(src)
fails = []

dicts = []
for node in ast.walk(tree):
    if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
            and node.func.attr == 'append' and isinstance(node.func.value, ast.Name)
            and node.func.value.id == 'out_towns' and node.args
            and isinstance(node.args[0], ast.Dict)):
        keys = {k.value for k in node.args[0].keys if isinstance(k, ast.Constant)}
        dicts.append((node.lineno, keys))
if len(dicts) != 2:
    fails.append(f'預期 2 個 out_towns.append 字典，實得 {len(dicts)}')
else:
    pat = re.compile(r'^(qpf_(?!15d|24h|48h|1h|radar|cwa|hi|lo)\w+|maxh_\w+|warn_seg\w*|hourly_ifs)$')
    (l1, k1), (l2, k2) = dicts
    m1 = {k for k in k1 if pat.match(k)}; m2 = {k for k in k2 if pat.match(k)}
    if m1 - m2: fails.append(f'非靜態分支（第 {l2} 行）缺欄位：{sorted(m1 - m2)}')
    if m2 - m1: fails.append(f'靜態分支（第 {l1} 行）缺欄位：{sorted(m2 - m1)}')
    print(f'模式欄位：靜態 {len(m1)}、非靜態 {len(m2)}')

# 2. 取用的模式鍵必須在抓取清單內
ns = {}
for name in ('OM_PHYSICAL', 'OM_AI', 'OM_VERIFY_A', 'OM_VERIFY_B'):
    m = re.search(rf'^{name}\s*=\s*(\[[^\]]*\])', src, re.M | re.S)
    if not m: fails.append(f'找不到 {name}'); continue
    ns[name] = ast.literal_eval(re.sub(r'#[^\n]*', '', m.group(1)))
fetched = set(sum(ns.values(), [])) | {'ecmwf_ifs025'}      # 025 為 HRES 失敗時的退路
used = set(re.findall(r"get_(?:qpf_model|ns_qpf|max_hourly_model|ns_maxh)\('([\w]+)'\)", src))
bad = used - fetched
if bad: fails.append(f'取用了不會被抓的模式鍵：{sorted(bad)}')
print(f'取用模式鍵 {len(used)} 個，皆在抓取清單內' if not bad else '')

# 3. ecmwf_ifs025 只能當退路
for i, line in enumerate(src.split('\n'), 1):
    if "'ecmwf_ifs025'" not in line or line.strip().startswith('#'): continue
    if "'ecmwf_ifs'" in line or 'model_names' in line or "'ECMWF IFS 0.25" in line: continue
    if 'fetch_openmeteo_model(townships' in line or "om_all.get('ecmwf_ifs')" in line: continue
    if "non_static_om.get('ecmwf_ifs025'" in line: continue   # 緊接在 ecmwf_ifs 之後的 or 退路
    fails.append(f'第 {i} 行單獨取用 ecmwf_ifs025：{line.strip()[:90]}')

for f in fails: print('FAIL', f)
print('PASS' if not fails else f'FAIL ×{len(fails)}')
sys.exit(1 if fails else 0)
