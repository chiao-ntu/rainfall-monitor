// 道路／避難收容所疊圖：開得起來、關得乾淨、而且不可拖慢或擋住既有功能。
//
// 最重要的兩條（過去踩過的坑）：
//   ‧ Canvas 渲染下 pane 是整片元素，不關指標事件就會蓋住鄉鎮色塊 → 地圖點不到
//   ‧ 疊圖不得拖慢 renderLayer（鄉鎮著色是主要功能，不能被選用圖層拖累）
const puppeteer=require('puppeteer');
const fs=require('fs');
// ★ 瀏覽器路徑必須隨環境決定，不可寫死。
//   先前寫死本機容器的 /opt/pw-browsers/...，在 GitHub Actions 上
//   會以 "Browser was not found at the configured executablePath" 失敗。
//   找不到既有路徑就不指定 executablePath，讓 puppeteer 用自己下載的 Chromium。
const _EXEC=[process.env.PUPPETEER_EXECUTABLE_PATH,
  '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  '/opt/pw-browsers/chromium/chrome-linux/chrome'].find(p=>p&&fs.existsSync(p));
const _LAUNCH={args:['--no-sandbox','--disable-dev-shm-usage']};
if(_EXEC) _LAUNCH.executablePath=_EXEC;

(async()=>{
 const b=await puppeteer.launch(Object.assign({}, _LAUNCH, {defaultViewport:{width:1400,height:900}}));
 const pg=await b.newPage(); const errs=[];
 pg.on('pageerror',e=>errs.push(String(e).slice(0,170)));
 await pg.goto('http://127.0.0.1:8899/_local.html',{waitUntil:'networkidle2',timeout:90000});
 await new Promise(r=>setTimeout(r,8000));
 const R=await pg.evaluate(async()=>{
  const fails=[], log=[];
  const ok=(c,m)=>{ if(!c) fails.push(m); log.push((c?'OK  ':'!!  ')+m); };
  const wait=ms=>new Promise(r=>setTimeout(r,ms));

  // ── ① 按鈕存在且在行政區名右邊 ──
  const tn=document.getElementById('bTownName');
  const rd=document.getElementById('bRoads');
  const sh=document.getElementById('bShelter');
  ok(!!rd && !!sh, '①兩個按鈕都存在');
  ok(tn && rd && (tn.compareDocumentPosition(rd) & Node.DOCUMENT_POSITION_FOLLOWING),
     '①道路按鈕排在「行政區名」之後');
  ok(tn && sh && tn.parentElement===rd.parentElement && rd.parentElement===sh.parentElement,
     '①三個按鈕在同一列（圖層列第二排）');

  // ── ② 未按下前不得載入資料（延遲載入）──
  ok(typeof _roadData!=='undefined' && _roadData===null,
     '②未按下前道路資料未載入（避免拖慢首頁）');

  // ── ③ 基準：未開疊圖時的 renderLayer 耗時 ──
  const bench=()=>{ const t=performance.now(); try{ renderLayer(); }catch(e){}
                    return performance.now()-t; };
  bench(); const base=Math.min(bench(),bench(),bench());

  // ── ④ 開啟道路（縮放到門檻以上）──
  map.setView([24.75,121.75],11,{animate:false});
  await wait(300);
  const t0=performance.now();
  await toggleRoadLayer();
  await wait(1200);
  const onMs=Math.round(performance.now()-t0);
  ok(_roadOn && _roadData, `④道路圖資載入成功（${(_roadData.features||[]).length} 段，${onMs}ms）`);
  ok(!!_roadLayer, '④道路圖層已加到地圖');

  // ── ⑤ pane 設定：必須在 townPane 之上、且不攔截點擊 ──
  const rp=map.getPane('roadPane');
  ok(!!rp, '⑤roadPane 已建立');
  ok(rp && +rp.style.zIndex > +map.getPane('townPane').style.zIndex,
     `⑤roadPane(${rp&&rp.style.zIndex}) 在 townPane(${map.getPane('townPane').style.zIndex}) 之上`);
  ok(rp && rp.style.pointerEvents==='none',
     '⑤roadPane 關閉指標事件（否則整片 canvas 會蓋住鄉鎮、地圖點不到）');

  // ── ⑥ 不得拖慢既有鄉鎮著色 ──
  const withRoad=Math.min(bench(),bench(),bench());
  ok(withRoad < base*2 + 20,
     `⑥renderLayer 未被拖慢：無疊圖 ${base.toFixed(0)}ms → 有道路 ${withRoad.toFixed(0)}ms`);

  // ── ⑦ 橋樑旗標有保留（使用者問「道路有包含橋樑嗎」）──
  const fs=_roadData.features||[];
  const nb=fs.filter(f=>f.properties&&f.properties.b).length;
  const nt=fs.filter(f=>f.properties&&f.properties.t).length;
  ok(nb>1000, `⑦含橋樑並可辨識：${nb} 段橋樑、${nt} 段隧道`);

  // ── ⑧ 預設視野就必須看得到（使用者回報：原本預設大小什麼都沒有）──
  //    不設縮放門檻，改為依縮放調整內容密度；介面上不出現任何縮放級數。
  map.setView([23.7,121.0],7,{animate:false});   // 全臺視野
  renderRoadLayer();
  ok(!!_roadLayer && _roadLayer.getLayers().length>0,
     `⑧全臺視野仍有道路（${_roadLayer?_roadLayer.getLayers().length:0} 組）`);
  const farN=_roadLayer.getLayers().length;
  ok(!/放大|級/.test(document.getElementById('bRoads').textContent),
     `⑧按鈕不出現縮放級數（實得「${document.getElementById('bRoads').textContent}」）`);
  map.setView([24.75,121.75],13,{animate:false});
  renderRoadLayer();
  const nearN=_roadLayer.getLayers().length;
  ok(nearN>farN, `⑧拉近後內容變密（遠 ${farN} 組 → 近 ${nearN} 組）`);

  // ── ⑧b 圖例：每個符號各佔一條，且不得有說明性文字 ──
  //    使用者指出：圖例需要寫說明＝設計失敗。
  const lg=document.getElementById('overlay-legend');
  ok(lg && lg.style.display!=='none', '⑧b 道路圖例已顯示');
  const lt=lg.textContent;
  ok(/國道/.test(lt) && /快速道路/.test(lt) && /省道/.test(lt),
     '⑧b 圖例列出三種道路類別');
  ok(/橋樑/.test(lt) && /隧道/.test(lt),
     '⑧b 橋樑與隧道各自在圖例佔一條（不是靠文字解釋）');
  ok(!/拉近|滑過|可看|可分辨/.test(lt),
     `⑧b 圖例沒有任何說明性文字（實得「${lt.replace(/\s+/g,'').slice(0,60)}…」）`);

  // ── ⑧c tooltip 在游標旁，且含全部細部欄位 ──
  ok(typeof _roadAt==='function' && _roadIndex, '⑧c 道路索引已建立');
  const rp2=map.getPane('roadPane');
  ok(rp2.style.pointerEvents==='none',
     '⑧c roadPane 仍不攔截點擊（鄉鎮必須點得到）');
  const fr=_roadData.features.find(f=>f.properties&&f.properties.ref&&f.properties.sp);
  const cr=fr.geometry.coordinates[0];
  map.setView([cr[1],cr[0]],14,{animate:false});
  _onRoadMove({latlng:L.latLng(cr[1],cr[0])});
  ok(!!_roadTip, '⑧c 滑到道路上會開 tooltip');
  const rh=_roadTip.getContent();
  ok(/編號/.test(rh) && /速限/.test(rh),
     `⑧c tooltip 含編號與速限等細部欄位`);
  ok(!document.getElementById('overlay-legend').textContent.includes('編號'),
     '⑧c 道路資訊不再塞進圖例');
  // 離開道路要收掉
  _onRoadMove({latlng:L.latLng(cr[1]+0.5,cr[0]+0.5)});
  ok(!_roadTip, '⑧c 離開道路後 tooltip 收掉');

  // ── ⑧f 原始資料的欄位要全部帶進來 ──
  const keys=new Set();
  _roadData.features.slice(0,5000).forEach(f=>Object.keys(f.properties).forEach(k=>keys.add(k)));
  ['c','ref','name','ow','sp','b'].forEach(k=>
    ok(keys.has(k), `⑧f 道路屬性含 ${k}`));

  // ── ⑨ 避難收容所 ──
  await toggleShelterLayer();
  await wait(600);
  ok(_shelterOn && _shelterData, `⑨收容所載入成功（${(_shelterData.features||[]).length} 處）`);
  ok(!!_shelterLayer, '⑨收容所圖層已加到地圖');

  // ── ⑨b 收容所必須點得到（canvas 會被全域規則關掉指標事件）──
  const sm=_shelterLayer.getLayers()[0];
  ok(sm.options.pane==='shelterPane', `⑨b 收容所用自己的 pane（${sm.options.pane}）`);
  const sp=map.getPane('shelterPane');
  ok(sp && sp.style.pointerEvents!=='none', '⑨b shelterPane 指標事件開啟');
  ok(sp && sp.querySelector('svg'), '⑨b 以 SVG 渲染');
  const ll=sm.getLatLng();
  map.setView(ll,14,{animate:false});
  await wait(400);
  const pt=map.latLngToContainerPoint(ll);
  const rc=map.getContainer().getBoundingClientRect();
  const topEl=document.elementFromPoint(rc.left+pt.x, rc.top+pt.y);
  ok(topEl && sp.contains(topEl),
     `⑨b 游標落點最上層是收容所本身（實得 ${topEl?topEl.tagName:'null'}）`);

  // ── ⑨c hover 就要給出全部資訊，不必點進去 ──
  const tp=sm.getTooltip();
  ok(!!tp, '⑨c 有 hover tooltip');
  const th=tp.getContent();
  ['地址','開設類型','收容所','避難所','物資點','水災','土石流','震災','海嘯']
    .forEach(k=>ok(th.includes(k), `⑨c tooltip 含「${k}」`));

  // ── ⑨d 點選＝與右側狀態列連動（與測站同一套）──
  ok(typeof _townAtLatLng==='function', '⑨d 有經緯度→鄉鎮的判定');
  const tt=_townAtLatLng(ll.lat, ll.lng);
  ok(tt && tt.county, `⑨d 收容所位置判得出鄉鎮（${tt?tt.county+tt.township:'查無'}）`);
  const before=selected;
  sm.fire('click');
  await wait(200);
  ok(selected && selected !== before && selected.county,
     `⑨d 點選後右側狀態列切到該鄉鎮（${selected?selected.county+selected.township:'無'}）`);

  // ── ⑨e 鄉鎮仍然點得到 ──
  const far=map.latLngToContainerPoint(L.latLng(ll.lat+0.02, ll.lng+0.02));
  const topFar=document.elementFromPoint(rc.left+far.x, rc.top+far.y);
  ok(topFar && map.getPane('townPane').contains(topFar),
     `⑨e 非收容所處仍落在鄉鎮層（實得 ${topFar?topFar.tagName:'null'}）`);

  // ── ⑨f 雨量測站 tooltip 必須回來（同一個 canvas 根因）──
  //    ★ 示範資料沒有測站清單，不注入的話這組只會測到「沒有資料」，
  //      永遠失敗卻不代表程式有問題 —— 那是沒有意義的斷言。
  if(!window.ALL_STATIONS || !Object.keys(window.ALL_STATIONS).length){
    const t0 = TOWNSHIPS.find(x=>x.alert_val>0) || TOWNSHIPS[0];
    const c0 = (t0.lat!=null && t0.lng!=null) ? [t0.lat, t0.lng] : [24.75, 121.75];
    window.ALL_STATIONS = {
      TST1:{n:'測試站A', la:c0[0], lo:c0[1], r:12.5, e:320, c:t0.county, t:t0.township},
      TST2:{n:'測試站B', la:c0[0]+0.01, lo:c0[1]+0.01, r:null, e:80, c:t0.county, t:t0.township},
    };
  }
  if(_stnLayerOn) toggleStationLayer();
  toggleStationLayer();
  await wait(900);
  const sl=_stnLayer && _stnLayer.getLayers ? _stnLayer.getLayers() : [];
  ok(sl.length>0, `⑨f 測站圖層有點位（${sl.length}）`);
  ok(sl[0] && sl[0].options.pane==='stnPane',
     `⑨f 測站改用 SVG pane（${sl[0]?sl[0].options.pane:'無'}）`);
  ok(sl[0] && !!sl[0].getTooltip(), '⑨f 測站 tooltip 存在');
  const stH = sl[0] && sl[0].getTooltip() ? String(sl[0].getTooltip().getContent()) : '';
  ['今日累積','ETR2%','海拔'].forEach(k=>
    ok(stH.includes(k), `⑨f 測站 tooltip 含「${k}」`));
  ok(sl[0] && sl[0]._events && sl[0]._events.click,
     '⑨f 測站點選與右側狀態列連動');
  const spn=map.getPane('stnPane');
  ok(spn && spn.style.pointerEvents!=='none' && spn.querySelector('svg'),
     '⑨f stnPane 指標事件開啟且為 SVG');
  toggleStationLayer();

  // ── ⑨g 按鈕順序：行政區名 → 雨量測站 → 道路 ──
  const bs=document.getElementById('bStnLayer');
  ok(tn && bs && (tn.compareDocumentPosition(bs) & Node.DOCUMENT_POSITION_FOLLOWING),
     '⑨g 雨量測站在行政區名之後');
  ok(bs && rd && (bs.compareDocumentPosition(rd) & Node.DOCUMENT_POSITION_FOLLOWING),
     '⑨g 道路在雨量測站之後');

  // ── ⑩ 關閉後必須清乾淨 ──
  await toggleRoadLayer();
  await toggleShelterLayer();
  ok(!_roadLayer && !_shelterLayer, '⑩兩個圖層關閉後都已自地圖移除');
  const after=Math.min(bench(),bench(),bench());
  ok(after < base*2 + 20,
     `⑩關閉後 renderLayer 回到基準（${after.toFixed(0)}ms vs 基準 ${base.toFixed(0)}ms）`);

  return {fails, log};
 });
 console.log(R.log.join('\n'));
 if(errs.length) console.log('\n*** pageerror ***\n'+errs.join('\n'));
 console.log(`\n${R.fails.length?'FAIL '+R.fails.length:'ALL PASS'} / ${R.log.length} 項`);
 await b.close();
 process.exit(R.fails.length||errs.length?1:0);
})();
